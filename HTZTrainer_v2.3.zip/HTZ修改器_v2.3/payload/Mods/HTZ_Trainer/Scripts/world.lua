-- HTZ Trainer v1.1 - 世界控制（时间 / 天气 / 移速）
local util = require("util")
local game = require("game")
local config = require("config")

local world = {}

world.notify = function(msg, isErr) end

world.speedMult = tonumber(config.get("speed_mult")) or 1.0
world.SPEEDS = { 1.0, 1.5, 2.0, 3.0, 5.0 }
world.speedIdx = 1
world._baseSpeed = nil

-- ============ 时间 ============

world._timeProp = nil
local TIME_PROPS = { "Time of Day", "TimeOfDay", "Time Hour", "Internal Time of Day" }

--- 校准：探测可用的时间属性（游戏线程调用）
function world.calibrate()
    local sky = game.getSky()
    if not util.valid(sky) then
        util.log("世界校准: 未找到 Ultra_Dynamic_Sky_C")
        return false
    end
    world._timeProp = nil
    for _, p in ipairs(TIME_PROPS) do
        local ok, v = pcall(function() return sky[p] end)
        local n = ok and util.toNumber(v) or nil
        util.log(string.format("世界校准: 时间属性候选 %s = %s", p, tostring(n)))
        if n ~= nil and world._timeProp == nil then
            world._timeProp = p
        end
    end
    if world._timeProp then
        util.log("世界校准: 时间属性 = " .. world._timeProp)
    end
    -- 天气函数可用性检查
    local w = game.getWeather()
    if util.valid(w) then
        for _, fn in ipairs({ "FuncSelectRandomWeather", "Change Weather Using Settings", "Change Weather Using Type" }) do
            if w[fn] ~= nil then util.log("世界校准: 天气函数可用 " .. fn) end
        end
    end
    return world._timeProp ~= nil
end

-- 返回: 小时(0-24), 原始值
-- 游戏 Time of Day 为累计值(量级数百以上)，按“分钟”解释: 1440 分钟 = 1 天
local function rawToHour(n)
    if n == nil then return nil end
    if n > 48 then return (n % 1440) / 60, n end
    return n, n
end

function world.getTime()
    local sky = game.getSky()
    if not util.valid(sky) then return nil end
    if world._timeProp then
        local ok, v = pcall(function() return sky[world._timeProp] end)
        local n = ok and util.toNumber(v) or nil
        if n ~= nil then return rawToHour(n) end
        world._timeProp = nil
    end
    for _, p in ipairs(TIME_PROPS) do
        local ok, v = pcall(function() return sky[p] end)
        local n = ok and util.toNumber(v) or nil
        if n ~= nil then
            world._timeProp = p
            return rawToHour(n)
        end
    end
    return nil
end

function world.setTime(h)
    local sky = game.getSky()
    if not util.valid(sky) then
        world.notify("未找到天空系统", true)
        return false
    end
    if not world._timeProp then world.calibrate() end
    if not world._timeProp then
        world.notify("时间控制不可用", true)
        return false
    end
    h = h % 24
    local _, raw = rawToHour(util.toNumber(sky[world._timeProp]))
    local target
    if raw and raw > 48 then
        target = math.floor(raw / 1440) * 1440 + h * 60
    else
        target = h
    end
    local ok = pcall(function() sky[world._timeProp] = target end)
    if ok then
        world.notify(string.format("时间已设置为 %02d:00", math.floor(h)), false)
        return true
    end
    return false
end

function world.addTime(dh)
    local t = world.getTime()
    if t == nil then
        world.notify("时间读取失败", true)
        return
    end
    world.setTime(t + dh)
end

-- ============ 天气 ============

function world.cycleWeather()
    local w = game.getWeather()
    if not util.valid(w) then
        world.notify("未找到天气系统", true)
        return false
    end
    -- 无参优先（最安全）
    for _, fn in ipairs({ "FuncSelectRandomWeather", "Change Weather Using Settings" }) do
        if w[fn] ~= nil then
            local ok = pcall(function() w[fn](w) end)
            if ok then
                util.log("天气切换: " .. fn)
                world.notify("天气已切换 (" .. fn .. ")", false)
                return true
            end
        end
    end
    if w["Change Weather Using Type"] ~= nil then
        local ok = pcall(function() w["Change Weather Using Type"](w, math.random(0, 6)) end)
        if ok then
            world.notify("天气已切换", false)
            return true
        end
    end
    world.notify("天气控制不可用", true)
    return false
end

-- ============ 移动速度 ============

local function getMoveComp()
    local pawn = game.getPawn()
    if not util.valid(pawn) then return nil end
    local ok, comp = pcall(function() return pawn.CharacterMovement end)
    if ok and util.valid(comp) then return comp end
    local ok2, comp2 = pcall(function() return pawn.CharMoveComp end)
    if ok2 and util.valid(comp2) then return comp2 end
    return nil
end

function world.applySpeed()
    local comp = getMoveComp()
    if not util.valid(comp) then
        world.notify("未找到移动组件", true)
        return false
    end
    if world._baseSpeed == nil then
        local ok, cur = pcall(function() return comp.MaxWalkSpeed end)
        local n = ok and util.toNumber(cur) or nil
        world._baseSpeed = (n and n > 1) and n or 300
        util.log(string.format("基准移动速度: %.1f", world._baseSpeed))
    end
    local target = world._baseSpeed * world.speedMult
    local ok = pcall(function() comp.MaxWalkSpeed = target end)
    if ok then
        world.notify(string.format("移动速度: %.1f 倍 (%.0f)", world.speedMult, target), false)
        return true
    end
    return false
end

function world.cycleSpeed(dir)
    world.speedIdx = util.clamp(world.speedIdx + (dir or 1), 1, #world.SPEEDS)
    world.speedMult = world.SPEEDS[world.speedIdx]
    config.set("speed_mult", tostring(world.speedMult))
    config.save()
    world.applySpeed()
end

return world
