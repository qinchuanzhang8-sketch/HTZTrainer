-- 僵尸/怪物清单（从游戏 Pak 提取）
-- path = 蓝图生成类完整路径
local base = "/Game/TSS_Game/Animations/Zombies/AI/PawnZombie/ZombieClasses/"
local animals = "/Game/TSS_Game/Blueprints/Animals/"

local list = {
    { id = "BP_PawnZombie2",                 cn = "普通丧尸",       en = "Walker" },
    { id = "BP_PawnZombieCop",               cn = "警察丧尸",       en = "Cop" },
    { id = "BP_PawnZombieMedic",             cn = "医疗丧尸",       en = "Medic" },
    { id = "BP_PawnZombiePatient",           cn = "病号丧尸",       en = "Patient" },
    { id = "BP_PawnZombie_Female",           cn = "女性丧尸",       en = "Female" },
    { id = "BP_PawnZombie_Girl",             cn = "女孩丧尸",       en = "Girl" },
    { id = "BP_PawnZombie_Urban",            cn = "都市丧尸",       en = "Urban" },
    { id = "BP_PawnZombie_Police1",          cn = "警察丧尸·壹",    en = "Police 1" },
    { id = "BP_PawnZombie_Police2",          cn = "警察丧尸·贰",    en = "Police 2" },
    { id = "BP_PawnZombie_PoliceArmor",      cn = "防暴警察丧尸",   en = "Riot Police" },
    { id = "BP_PawnZombie_Prison",           cn = "囚犯丧尸",       en = "Prisoner" },
    { id = "BP_PawnZombie_Hazmat",           cn = "防化丧尸",       en = "Hazmat" },
    { id = "BP_PawnZombie_Camo",             cn = "迷彩军人丧尸",   en = "Camo Soldier" },
    { id = "BP_PawnZombie_MilitaryArmoured", cn = "军装重甲丧尸",   en = "Armored Soldier" },
    { id = "BP_PawnZombie_MilitaryArmouredv2", cn = "军装重甲丧尸·V2", en = "Armored Soldier V2" },
    { id = "BP_PawnZombie_Jumper",           cn = "跳跃丧尸",       en = "Jumper" },
    { id = "BP_PawnZombie_Runner",           cn = "狂奔丧尸",       en = "Runner" },
    { id = "BP_PawnZombie_NightRunner",      cn = "夜行狂奔丧尸",   en = "Night Runner" },
    { id = "BP_PawnZombie_MilitaryArmouredRunner", cn = "重甲狂奔丧尸", en = "Armored Runner" },
    { id = "BP_PawnZombie_Brute",            cn = "巨力丧尸",       en = "Brute" },
    { id = "BP_PawnZombie_BruteCop",         cn = "巨力警察丧尸",   en = "Brute Cop" },
    { id = "BP_PawnZombie_PrisonBrute",      cn = "巨力囚犯丧尸",   en = "Brute Prisoner" },
    { id = "BP_PawnZombie_RunnerBrute",      cn = "狂奔巨力丧尸",   en = "Runner Brute" },
    { id = "BP_PawnZombie_CamoBrute",        cn = "迷彩巨力丧尸",   en = "Camo Brute" },
    { id = "BP_PawnZombie_GiantBrute",       cn = "巨型丧尸",       en = "Giant Brute" },
    { id = "BP_PawnZombie_GiantBrutePrison", cn = "监狱巨型丧尸",   en = "Giant Prison Brute" },
    { id = "BP_PawnZombie_Pudge",            cn = "肥尸",           en = "Pudge" },
    { id = "BP_PawnZombie_BellyToxic",       cn = "毒腹丧尸",       en = "Toxic Belly" },
    { id = "BP_PawnZombie_Mutant",           cn = "变异丧尸",       en = "Mutant" },
    { id = "BP_PawnZombie_ZantaClawZ",       cn = "圣诞丧尸",       en = "Zanta" },
}

local out = {}
for _, e in ipairs(list) do
    table.insert(out, { id = e.id .. "_C", cn = e.cn, en = e.en, path = base .. e.id .. "." .. e.id .. "_C" })
end
table.insert(out, { id = "BP_ZombieBear_C", cn = "僵尸熊", en = "Zombie Bear", path = animals .. "BP_ZombieBear.BP_ZombieBear_C" })
table.insert(out, { id = "BP_ZombiStag_C", cn = "僵尸鹿", en = "Zombie Stag", path = animals .. "BP_ZombiStag.BP_ZombiStag_C" })
table.insert(out, { id = "BP_Dogzombie_C", cn = "僵尸狗", en = "Zombie Dog", path = animals .. "DogZombie/BP_Dogzombie.BP_Dogzombie_C" })

return out
