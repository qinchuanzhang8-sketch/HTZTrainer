-- HTZ Trainer v1.1 - 玩家属性层（生命/饥饿/口渴/耐力/感染/体温/电量）
-- 双层自适应：优先数组/属性路径（纯内存操作），失败则探测函数路径（主线程调用+读回验证）
-- 所有函数只在游戏主线程执行（由 main.tick / 按键 inGame 包装保证）
local util = require("util")
local game = require("game")

local stats = {}

stats.notify = function(msg, isErr) end

stats.TAGS = {
    health      = "Attributes.Health",
    maxstamina  = "Attributes.MaxStamina",
    stamina     = "Attributes.Stamina",
    hunger      = "Attributes.Hunger",
    thirst      = "Attributes.Thirst",
    infection   = "Attributes.Infection",
    temperature = "Attributes.Temperature",
    battery     = "Attributes.Battery",
}

stats.ATTR_CLASS = "/Game/Coredamage/AttributeComponent/DamageTypes/Attributes/DamageType_Attribute_"
stats.CLASS_PATHS = {
    health      = stats.ATTR_CLASS .. "Health.DamageType_Attribute_Health_C",
    maxstamina  = stats.ATTR_CLASS .. "Stamina.DamageType_Attribute_Stamina_C",
    stamina     = stats.ATTR_CLASS .. "Stamina.DamageType_Attribute_Stamina_C",
    hunger      = stats.ATTR_CLASS .. "Hunger.DamageType_Attribute_Hunger_C",
    thirst      = stats.ATTR_CLASS .. "Thirst.DamageType_Attribute_Thirst_C",
    infection   = stats.ATTR_CLASS .. "Infection.DamageType_Attribute_Infection_C",
    temperature = stats.ATTR_CLASS .. "Temperature.DamageType_Attribute_Temperature_C",
    battery     = stats.ATTR_CLASS .. "Battery.DamageType_Attribute_Battery_C",
}

-- 每个属性的 Update* 函数（候选写入方式）
stats.UPDATE_FNS = {
    health = "UpdateHealth", hunger = "UpdateHunger", thirst = "UpdateThirst",
    stamina = "UpdateStamina", infection = "UpdateInfection",
    temperature = "UpdateTemperature", battery = "UpdateBattery",
}

-- 直接属性名（侦察确认：属性就是组件上的普通 float 属性，首选读写方式）
stats.PROPS = {
    health = "health", maxstamina = "MaxStamina", stamina = "Stamina",
    hunger = "Hunger", thirst = "Thirst", infection = "infection",
    temperature = "Temperature", battery = "Battery",
}
stats.PROPS_OK = false

-- 伴随字段：锁定主属性时同步写入，防止游戏自身逻辑用"历史值"回写覆盖
-- save=true 的字段在启用锁定时记录原值、关闭锁定时恢复（倍率/速率类）
stats.EXTRA_WRITES = {
    health      = {
        { p = "PreviousHealth", v = "same" },
        { p = "ExtraHealthDrain", v = false },
        { p = "HealthDrainRate", v = 0, save = true },
        { p = "HealthDrainAmount", v = 0, save = true },
        { p = "HealthUpdateMultiplier", v = 0, save = true },
        { p = "HealthMultiplier", v = 0, save = true },
        { p = "MetabolismMultiplier", v = 0, save = true },
    },
    stamina     = {
        { p = "PreviousStamina", v = "same" },
        { p = "StaminaDrainRate", v = 0, save = true },
        { p = "StaminaRegenRate", v = 0, save = true },
        { p = "StaminaDrainAmount", v = 0, save = true },
        { p = "StaminaUpdateMultiplier", v = 0, save = true },
    },
    hunger      = {
        { p = "PreviousHunger", v = "same" },
        { p = "HungerDrainRate", v = 0, save = true },
        { p = "HungerUpdateMultipler", v = 0, save = true },
        { p = "HungerDrainAmount", v = 0, save = true },
    },
    thirst      = {
        { p = "PreviousThirst", v = "same" },
        { p = "ThirstDrainRate", v = 0, save = true },
        { p = "ThirstUpdateMultiplier", v = 0, save = true },
        { p = "ThirstDrainAmount", v = 0, save = true },
    },
    infection   = {
        { p = "PreviousInfection", v = "same" },
        { p = "InfectionUpdateMultiplier", v = 0, save = true },
        { p = "InfectionDrainAmount", v = 0, save = true },
    },
    temperature = {
        { p = "PreviousTemperature", v = "same" },
        { p = "TemperatureUpdateMultiplier", v = 0, save = true },
    },
    battery     = {
        { p = "PreviousBattery", v = "same" },
        { p = "BatteryModifier", v = 0, save = true },
    },
}

-- 可恢复字段的原值存档 { key -> { prop -> origin } }
stats._savedExtras = {}

stats.DISPLAY = {
    { key = "health",      cn = "生命", en = "HP"    },
    { key = "stamina",     cn = "耐力", en = "STA"   },
    { key = "hunger",      cn = "饥饿", en = "FOOD"  },
    { key = "thirst",      cn = "口渴", en = "WATER" },
    { key = "infection",   cn = "感染", en = "INF"   },
    { key = "temperature", cn = "体温", en = "TEMP"  },
    { key = "battery",     cn = "电量", en = "BATT"  },
}

stats.lockTargets = {
    health = 100, stamina = 100, hunger = 100,
    thirst = 100, infection = 0, temperature = 37, battery = 100,
}

stats.locks = {}
stats.values = {}
stats.godMode = false

stats.calibrated = false
stats.calibNote = "未校准"    -- 显示在菜单
stats._reader = nil           -- {fn=, form=}
stats._writer = nil           -- {fn=, form=} 或 {mode="arr"}
stats._arrInfo = nil          -- {arr=, keys={key->index}, valueField=}

-- ============ 参数构造 ============

local ARG_FORMS = {
    { name = "str",   build = function(tag, key) return tag end },
    { name = "FName", build = function(tag, key) return FName(tag) end },
    { name = "class", build = function(tag, key)
        local p = stats.CLASS_PATHS[key]
        if not p then return nil end
        local ok, c = pcall(StaticFindObject, p)
        if ok and util.valid(c) then return c end
        return nil
    end },
    { name = "gtag",  build = function(tag, key) return { TagName = FName(tag) } end },
}

local function unwrapParam(p)
    if p == nil then return nil end
    local ut = nil
    pcall(function() ut = p:type() end)
    if ut == "RemoteUnrealParam" or ut == "LocalUnrealParam" then
        local inner = nil
        pcall(function() inner = p:get() end)
        return inner or p
    end
    return p
end

local function saneNumber(v)
    if v == nil then return nil end
    if v >= -100 and v <= 10000 then return v end
    return nil
end

-- ============ 数组路径 ============

local KEY_MATCH_ORDER = { "maxstamina", "health", "stamina", "hunger", "thirst", "infection", "temperature", "battery" }
-- 每个键用于匹配的关键词（注意 maxstamina 优先）
local KEY_TOKENS = {
    maxstamina  = { "maxstamina", "max_stamina" },
    health      = { "health" },
    stamina     = { "stamina" },
    hunger      = { "hunger" },
    thirst      = { "thirst" },
    infection   = { "infection" },
    temperature = { "temperature" },
    battery     = { "battery" },
}

local function matchKey(text)
    if not text then return nil end
    local lower = text:lower()
    for _, key in ipairs(KEY_MATCH_ORDER) do
        for _, tok in ipairs(KEY_TOKENS[key]) do
            if lower:find(tok, 1, true) then return key end
        end
    end
    return nil
end

function stats._tryArrayPath(comp)
    local arr = nil
    if not pcall(function() arr = comp.AttributeValues end) or arr == nil then
        util.log("属性校准: 无 AttributeValues 属性")
        return false
    end
    local n = nil
    pcall(function() n = arr:GetArrayNum() end)
    if not (n and n > 0 and n < 200) then
        util.log("属性校准: AttributeValues 元素数异常 " .. tostring(n))
        return false
    end
    util.log(string.format("属性校准: 发现 AttributeValues 数组 (%d 项)", n))

    -- 探索元素字段
    local first = unwrapParam(arr[1])
    if first == nil then return false end
    local valueField, tagField = nil, nil
    local found = {}
    for _, f in ipairs({ "TagName", "Attribute", "AttributeType", "Type", "Value", "CurrentValue", "Max", "AttributeMax", "MaxValue" }) do
        local v = nil
        pcall(function() v = first[f] end)
        if v ~= nil then
            local sv = util.toString(v)
            local nv = util.toNumber(v)
            local objName = nil
            if sv == nil then
                local obj = unwrapParam(v)
                if util.valid(obj) then pcall(function() objName = obj:GetFullName() end) end
            end
            table.insert(found, string.format("%s=%s", f, sv or objName or tostring(nv)))
            if valueField == nil and nv ~= nil and f:lower():find("value") and not f:lower():find("max") then
                valueField = f
            end
            if tagField == nil and (sv ~= nil or objName ~= nil) then
                tagField = f
            end
        end
    end
    util.log("属性校准: 数组元素字段: " .. table.concat(found, " | "))
    if valueField == nil then
        util.log("属性校准: 未找到值字段")
        return false
    end

    -- 建立 键→索引 映射
    local keys = {}
    local function scanElem(i, elem)
        local s = unwrapParam(elem)
        if s == nil then return end
        local text = nil
        if tagField then
            pcall(function() text = util.toString(s[tagField]) end)
            if text == nil then
                local obj = nil
                pcall(function() obj = s[tagField] end)
                obj = unwrapParam(obj)
                if util.valid(obj) then pcall(function() text = obj:GetFullName() end) end
            end
        end
        local key = matchKey(text)
        if key and keys[key] == nil then keys[key] = i end
    end
    pcall(function()
        arr:ForEach(function(i, elem)
            if i > 64 then return true end
            scanElem(i, elem)
        end)
    end)
    -- ForEach 不可用时逐项扫描
    if next(keys) == nil then
        for i = 1, math.min(n, 32) do
            pcall(function() scanElem(i, arr[i]) end)
        end
    end

    local cnt = 0
    for _ in pairs(keys) do cnt = cnt + 1 end
    util.log(string.format("属性校准: 数组路径匹配到 %d/7 个属性", cnt))
    if cnt >= 4 then
        stats._arrInfo = { arr = arr, keys = keys, valueField = valueField }
        return true
    end
    return false
end

local function arrRead(key)
    local ai = stats._arrInfo
    if not ai or not ai.keys[key] then return nil end
    local v = nil
    pcall(function()
        local elem = ai.arr[ai.keys[key]]
        local s = unwrapParam(elem)
        if s ~= nil then v = util.toNumber(s[ai.valueField]) end
    end)
    return saneNumber(v)
end

local function arrWrite(key, value)
    local ai = stats._arrInfo
    if not ai or not ai.keys[key] then return false end
    local ok = pcall(function()
        local elem = ai.arr[ai.keys[key]]
        local s = unwrapParam(elem)
        if s == nil then error("no elem") end
        -- 尝试直接改元素结构体字段（就地写内存）
        s[ai.valueField] = value
    end)
    if ok then
        local back = arrRead(key)
        if back and math.abs(back - value) < 0.75 then return true end
    end
    -- 尝试整体回写数组元素
    ok = pcall(function()
        local elem = ai.arr[ai.keys[key]]
        local s = unwrapParam(elem)
        ai.arr[ai.keys[key]] = s
    end)
    if ok then
        local back = arrRead(key)
        if back and math.abs(back - value) < 0.75 then return true end
    end
    return false
end

-- ============ 函数路径 ============

function stats._callRead(comp, fnName, formIdx, key)
    local form = ARG_FORMS[formIdx]
    if not form then return nil end
    local arg = form.build(stats.TAGS[key], key)
    if arg == nil then return nil end
    local ok, ret = pcall(function() return comp[fnName](comp, arg) end)
    if not ok then return nil end
    return saneNumber(util.toNumber(ret))
end

function stats._probeReader(comp, sampleKey)
    local firstPass = { "GetCurrentAttributeValue", "GetAttributeValue" }
    local secondPass = { "GetModifiedValue", "GetAttributeValues" }
    for _, pass in ipairs({ firstPass, secondPass }) do
        for _, fn in ipairs(pass) do
            for fi = 1, #ARG_FORMS do
                local v = stats._callRead(comp, fn, fi, sampleKey)
                if v ~= nil then
                    stats._reader = { fn = fn, form = fi }
                    util.log(string.format("属性校准: 读取 = %s / 参数形式=%s / 样本值=%.1f",
                        fn, ARG_FORMS[fi].name, v))
                    return true
                end
            end
        end
    end
    util.log("属性校准: 未找到可用的读取函数")
    return false
end

local function readRaw(key)
    local comp = game.getAttrComp()
    if not util.valid(comp) then return nil end
    -- 首选：直接属性
    if stats.PROPS_OK and stats.PROPS[key] then
        local pv = nil
        pcall(function() pv = comp[stats.PROPS[key]] end)
        local n = util.toNumber(pv)
        if n ~= nil then return n end
    end
    local v = arrRead(key)
    if v ~= nil then return v end
    if stats._reader then
        local ok = util.safe(function()
            v = stats._callRead(comp, stats._reader.fn, stats._reader.form, key)
        end)
        if ok and v ~= nil then return v end
        stats._reader = nil
    end
    return nil
end

stats.read = readRaw

function stats._probeWriter(comp)
    -- 读取必须可用才能验证
    local cur = readRaw("health")
    local target, restore = nil, nil
    if cur and cur >= 2 then
        target = math.floor(cur - 1)
        restore = cur
    end

    local candidates = {}
    for _, fn in ipairs({ "SetAttributeValue", "SetAttribute", "ChangeAttributeValue", "UpdateAttribute", "SetStat", "SetVital", "ModifyAttribute", "ChangeAttribute" }) do
        table.insert(candidates, fn)
    end
    table.insert(candidates, "UpdateHealth")
    table.insert(candidates, "AutoGenFunc")
    table.insert(candidates, "AutoGenFunc1")

    local function tryForms(fnName)
        for fi = 1, #ARG_FORMS do
            local form = ARG_FORMS[fi]
            local arg = form.build(stats.TAGS.health, "health")
            if arg ~= nil and target then
                local ok = pcall(function() comp[fnName](comp, arg, target) end)
                if ok then
                    local back = readRaw("health")
                    if back and math.abs(back - target) < 0.75 then
                        -- 恢复原值
                        pcall(function() comp[fnName](comp, arg, restore) end)
                        stats._writer = { fn = fnName, form = fi }
                        util.log(string.format("属性校准: 写入 = %s / 参数形式=%s (验证通过)", fnName, form.name))
                        return true
                    else
                        util.log(string.format("  写入尝试 %s/%s: 调用成功但未生效 (%.1f→%.1f)",
                            fnName, form.name, cur or -1, back or -1))
                    end
                end
            end
            -- 值在前参数顺序
            if arg ~= nil and target then
                local ok = pcall(function() comp[fnName](comp, target, arg) end)
                if ok then
                    local back = readRaw("health")
                    if back and math.abs(back - target) < 0.75 then
                        pcall(function() comp[fnName](comp, restore, arg) end)
                        stats._writer = { fn = fnName, form = fi, swapped = true }
                        util.log(string.format("属性校准: 写入 = %s / 参数形式=%s(值在前) (验证通过)", fnName, form.name))
                        return true
                    end
                end
            end
        end
        return false
    end

    if target == nil then
        for _, fnName in ipairs(candidates) do
            if comp[fnName] ~= nil then
                stats._writer = { fn = fnName, form = 1 }
                util.log("属性校准: 写入取样受阻, 采用未验证候选 " .. fnName)
                return true
            end
        end
        return false
    end

    for _, fnName in ipairs(candidates) do
        if comp[fnName] ~= nil then
            if tryForms(fnName) then return true end
        end
    end
    util.log("属性校准: 未找到可用的写入函数")
    return false
end

function stats.write(key, value)
    local comp = game.getAttrComp()
    if not util.valid(comp) then return false end
    -- 首选：直接属性写入（连同伴随字段同步）
    if stats.PROPS_OK and stats.PROPS[key] then
        local ok = pcall(function() comp[stats.PROPS[key]] = value end)
        if ok then
            local v = nil
            pcall(function() v = util.toNumber(comp[stats.PROPS[key]]) end)
            if v ~= nil and math.abs(v - value) < 2.5 then
                local extras = stats.EXTRA_WRITES[key]
                if extras then
                    for _, ex in ipairs(extras) do
                        if ex.save then
                            -- 首次写入前记录原值（关闭锁定时恢复）
                            local store = stats._savedExtras[key]
                            if store == nil then
                                store = {}
                                stats._savedExtras[key] = store
                            end
                            if store[ex.p] == nil then
                                local orig = nil
                                pcall(function() orig = util.unwrap(comp[ex.p]) end)
                                store[ex.p] = orig or false
                            end
                        end
                        if ex.v == "same" then
                            pcall(function() comp[ex.p] = value end)
                        else
                            pcall(function() comp[ex.p] = ex.v end)
                        end
                    end
                end
                return true
            end
        end
    end
    if stats._arrInfo and stats._arrInfo.keys[key] then
        if arrWrite(key, value) then return true end
    end
    local w = stats._writer
    if w and w.fn then
        local form = ARG_FORMS[w.form]
        if form then
            local arg = form.build(stats.TAGS[key], key)
            if arg ~= nil then
                local ok = false
                if w.swapped then
                    ok = pcall(function() comp[w.fn](comp, value, arg) end)
                else
                    ok = pcall(function() comp[w.fn](comp, arg, value) end)
                end
                if ok then return true end
            end
        end
    end
    return false
end

-- ============ 校准入口 ============

function stats.calibrate()
    local comp = game.getAttrComp()
    if not util.valid(comp) then
        stats.calibNote = "未找到属性组件"
        util.log("属性校准失败: 未找到 BP_AttributeComponent_C")
        return false
    end
    util.log("====== 属性系统校准开始 ======")
    stats._reader, stats._writer, stats._arrInfo = nil, nil, nil

    -- 0) 首选：直接 float 属性（侦察已确认 health/Stamina/Hunger/Thirst/infection/Temperature/Battery）
    local propOK = 0
    for key, prop in pairs(stats.PROPS) do
        local v = nil
        pcall(function() v = comp[prop] end)
        local n = util.toNumber(v)
        if n ~= nil and n >= -1000 and n <= 100000 then
            propOK = propOK + 1
        else
            util.log(string.format("校准: 属性 %s (%s) 读取失败 (%s)", key, prop, tostring(v)))
        end
    end
    util.log(string.format("校准: 直接属性可用 %d/8", propOK))
    if propOK >= 5 then
        stats.PROPS_OK = true
        -- 直写测试：health-1 再恢复
        local cur = util.toNumber(comp["health"])
        if cur and cur >= 2 then
            local t1 = math.floor(cur - 1)
            local wok = pcall(function() comp["health"] = t1 end)
            local back = util.toNumber(comp["health"])
            pcall(function() comp["health"] = cur end)
            util.log(string.format("校准: 属性直写测试 %s (%.1f→%s→恢复%.1f)",
                tostring(wok), cur, tostring(back), cur))
        end
        stats.calibrated = true
        stats.calibNote = "属性直读直写 x" .. propOK
        util.log("====== 属性校准结果: " .. stats.calibNote .. " ======")
        return true
    end

    -- 先转储组件函数表（纯读取，安全；即使后续探测失败也可离线分析）
    util.safe(function()
        util.log("校准阶段: 转储组件函数表(仅一次)...")
        game.dumpClass(comp,
            "get|set|update|attribute|value|drain|health|hunger|thirst|stamina|infect|temperature|battery|bleed|heal|vital|stat|consume|food|water|buff|timer|modif|condit|sick|symptom", 400)
    end)

    util.log("校准阶段: 数组路径探测")
    stats._tryArrayPath(comp)
    if not stats._reader then
        util.log("校准阶段: 读取函数探测")
        util.safe(function() stats._probeReader(comp, "health") end)
    end
    if not stats._writer then
        util.log("校准阶段: 写入函数探测")
        util.safe(function() stats._probeWriter(comp) end)
    end

    local parts = {}
    if stats._arrInfo then
        local cnt = 0
        for _ in pairs(stats._arrInfo.keys) do cnt = cnt + 1 end
        table.insert(parts, string.format("数组×%d", cnt))
    end
    if stats._reader then table.insert(parts, "读:" .. stats._reader.fn) end
    if stats._writer then
        table.insert(parts, "写:" .. (stats._writer.fn or "数组"))
    end
    stats.calibNote = (#parts > 0) and table.concat(parts, " ") or "校准失败"
    util.log("====== 属性校准结果: " .. stats.calibNote .. " ======")

    stats.calibrated = true
    return (#parts > 0)
end

-- ============ 显示 / 锁定 ============

function stats.refreshValues()
    for _, d in ipairs(stats.DISPLAY) do
        local v = readRaw(d.key)
        if v ~= nil then stats.values[d.key] = v end
    end
end

--- 仅统计状态锁定（不含上帝模式）
function stats.anyLockOnly()
    for _, on in pairs(stats.locks) do if on then return true end end
    return false
end

function stats.anyLockOn()
    if stats.godMode then return true end
    for _, on in pairs(stats.locks) do if on then return true end end
    return false
end

--- 恢复某属性锁定时改写的"可恢复字段"（倍率/速率类）到原值
local function restoreExtras(key)
    local saved = stats._savedExtras[key]
    stats._savedExtras[key] = nil
    if not saved then return end
    local comp = game.getAttrComp()
    if not util.valid(comp) then return end
    for p, v in pairs(saved) do
        if v ~= nil and v ~= false then
            util.safe(function() comp[p] = v end)
        end
    end
    util.log("锁定恢复: " .. key .. " 附加字段已还原")
end

function stats.toggleAllLocks(on)
    for k in pairs(stats.lockTargets) do
        stats.locks[k] = on and true or false
        if not on then restoreExtras(k) end
    end
    stats.notify(on and "状态锁定: 全部开启" or "状态锁定: 全部关闭(原值已恢复)", false)
end

local lastLockWarn = 0
function stats.applyLocks()
    if not stats.PROPS_OK and stats._arrInfo == nil and stats._writer == nil then
        if os.clock() - lastLockWarn > 20 then
            lastLockWarn = os.clock()
            stats.notify("锁定失败: 属性写入未校准", true)
        end
        return
    end
    if stats.godMode then
        -- 上帝模式 = 全部属性锁定（含各属性消耗速率/倍率归零）
        for key in pairs(stats.lockTargets) do
            stats.write(key, stats.lockTargets[key])
        end
    else
        for key, on in pairs(stats.locks) do
            if on then
                stats.write(key, stats.lockTargets[key])
            end
        end
    end
end

-- ============ 上帝模式 ============

-- 角色上的上帝模式标志属性（SDK转储确认: BP_CharacterBase bool GodMode? @0x1450）
local GOD_PROPS = { "GodMode?", "GodeMode?", "bGodMode", "WasGodMode?" }

local function readGodFlag(obj)
    if not util.valid(obj) then return nil, nil end
    for _, p in ipairs(GOD_PROPS) do
        local v = nil
        util.safe(function() v = obj[p] end)
        if v ~= nil then
            local b = util.unwrap(v)
            if type(b) == "boolean" then return b, p end
        end
    end
    return nil, nil
end

local function writeGodFlag(obj, value)
    if not util.valid(obj) then return nil, nil end
    for _, p in ipairs(GOD_PROPS) do
        local ok = util.safe(function() obj[p] = value end)
        if ok then
            local b = readGodFlag(obj)
            if b == value then return true, p end
        end
    end
    return nil, nil
end

function stats.setGodMode(on)
    local pc = game.getPC()
    local pawn = game.getPawn()
    stats.godMode = on and true or false

    if on then
        local used, verified = nil, nil
        -- 首选：直接写角色 GodMode? 布尔属性（确定性写入，无切换歧义）
        if util.valid(pawn) then
            local ok, prop = writeGodFlag(pawn, true)
            if ok then
                used = "pawn." .. prop
                verified = true
            end
        end
        -- 回退：控制器原生函数
        if verified == nil and util.valid(pc) then
            for _, fn in ipairs({ "SERVER_GodMode", "SERVER_ToggleGodModeFor" }) do
                local f = nil
                util.safe(function() f = pc[fn] end)
                if f ~= nil then
                    local ok1 = pcall(function() return f(pc) end)
                    if not ok1 then pcall(function() return f(pc, true) end) end
                    used = "pc." .. fn
                    break
                end
            end
            verified = readGodFlag(pawn)
            if verified == nil and util.valid(pc) then verified = readGodFlag(pc) end
        end
        stats._godFnUsed = used
        stats.godModeState = verified
        util.log(string.format("上帝模式: 方式=%s 实际状态=%s", tostring(used), tostring(verified)))
        stats.notify("上帝模式: 开启" .. (verified == false and " (写入未验证, 血量锁兜底)" or ""), false)
    else
        local done = false
        if util.valid(pawn) then
            done = writeGodFlag(pawn, false) and true or false
        end
        if not done and stats._godFnUsed and stats._godFnUsed:sub(1, 3) == "pc." and util.valid(pc) then
            local fn = stats._godFnUsed:sub(4)
            pcall(function() pc[fn](pc) end)
        end
        -- 上帝模式带来的附加字段改写：未被单独锁定开启的属性恢复原值
        for k in pairs(stats.lockTargets) do
            if not stats.locks[k] then
                util.safe(function() restoreExtras(k) end)
            end
        end
        util.log("上帝模式: 关闭")
        stats.notify("上帝模式: 关闭", false)
    end
    return true
end

-- ============ 异常清除 ============

function stats.healAll()
    local n = 0
    for k, v in pairs(stats.lockTargets) do
        if not (k == "health" and stats.godMode) then
            if stats.write(k, v) then n = n + 1 end
        end
    end
    stats.clearDebuffs(true)
    stats.notify(string.format("已尝试补满 (%d/6 项)", n), false)
end

function stats.clearDebuffs(silent)
    local comp = game.getAttrComp()
    local cleared = {}
    if util.valid(comp) then
        for _, fn in ipairs({ "BleedClear", "ClearBleeding", "StopBleeding", "CureInfection", "RemoveAllAfflictions", "ClearAfflictions" }) do
            if comp[fn] ~= nil then
                local ok = pcall(function() comp[fn](comp) end)
                if ok then table.insert(cleared, fn) end
            end
        end
    end
    stats.write("infection", 0)
    if not silent and #cleared > 0 then
        stats.notify("已清除: " .. table.concat(cleared, ", "), false)
    end
    util.log("清除异常: " .. (#cleared > 0 and table.concat(cleared, ",") or "无可用函数(感染已归零)"))
end

return stats
