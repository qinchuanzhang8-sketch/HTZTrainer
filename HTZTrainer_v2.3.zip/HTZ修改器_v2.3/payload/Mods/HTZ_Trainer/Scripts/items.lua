-- HTZ Trainer v1.1.2 - 物品生成器（分类 + 全量枚举含隐藏物品）
-- 枚举策略:
--   方式A(默认,安全): 读 DT_ItemDatabase.RowMap 属性 (纯内存, 零风险)
--   方式B(实验,默认禁用): 原生函数 GetDataTableRowNames (已知会崩溃, 需 allow_dtfn.txt 显式许可)
--   兜底: 内置提取表 data_items.lua (714条)
local util = require("util")
local game = require("game")
local config = require("config")

-- 中文名映射（人工翻译表）
local zhMap = {}
do
    local ok, m = pcall(require, "items_zh")
    if ok and type(m) == "table" then zhMap = m end
end

local items = {}

items.notify = function(msg, isErr) end

-- ============ 分类 ============

items.CATS = {
    { id = "all",    cn = "全部物品",  en = "All" },
    { id = "ranged", cn = "远程武器",  en = "Ranged Weapons" },
    { id = "melee",  cn = "近战武器",  en = "Melee Weapons" },
    { id = "ammo",   cn = "弹药箭矢",  en = "Ammo" },
    { id = "food",   cn = "食物饮品",  en = "Food & Drink" },
    { id = "med",    cn = "医疗药品",  en = "Medicine" },
    { id = "mat",    cn = "材料资源",  en = "Materials" },
    { id = "cloth",  cn = "服装装备",  en = "Clothing" },
    { id = "tool",   cn = "工具杂物",  en = "Tools" },
    { id = "other",  cn = "其他/特殊",  en = "Other/Hidden" },
}
local CAT_INDEX = {}
for i, c in ipairs(items.CATS) do CAT_INDEX[c.id] = i end

local KEYWORDS = {
    ammo   = "12g|22ammo|308win|357|45acp|50cal|556|68mm|762|9mm|ammo|flareammo|glammo|rpgammo|shell|bolt|arrow|hc_ammo|shredderammo|brasscasing|grenade",
    med    = "medkit|bandage|painkill|antibiot|pills|tablets|treatment|syringe|multivit|heatpack|inhibtor|waterpurify|watertabs|irrplasma|dexcough",
    ranged = "ak47|ar15|awm|l85a2|ump45|uzi|revolver|pistol|1911|glock|fn57|deserteagle|rugar|m1|m4|mk18|scar|barrett|mosin|winchester|zm7|svd|p90|aa12|mini30|rifle|shotgun|smg|flamethrower|flaregun|nailgun|woodbow|comboundbow|crossbow|bow|rpg|rangedweapon",
    melee  = "baseballbat|barbedbat|nailedbat|sawbladebat|steelbat|cricketbat|apocbat|batcleaver|baton|axe|hammer|knife|cleaver|katana|machette|spear|sword|scythe|pitchfork|apocmace|morgenstern|crowbar|wrench|screwdriver|shovel|hatchet|chainsaw|handsaw|golfclub|trowel|broom|sledge|metalpipe|hockeystick|knuckle|shiv|clippers|weapon",
    food   = "soup|stew|meat|jerky|rice|tuna|beans|sardines|jam|honey|coffee|kola|cola|milk|water|juice|nuts|crisps|candy|chocolate|soda|carrot|potato|tomato|cabbage|onion|corn|watermelon|pumpkinslice|berries|perch|salmon|pike|fish|egg|bread|noodles|crackers|cereal|mre|beer|wine|vodka|whisky|mead|liquor|tea|energybar|energydrink|apple|preserves|chili|peas|peanutbutter|flour",
    cloth  = "hoodie|shirt|pants|shorts|jacket|coat|beanie|boots|trainers|hitops|gloves|scarf|mask|vest|helmet|helm|poncho|bandana|balaclava|ushanka|glasses|goggles|cap|hat|sock|apron|jeans|armor",
    mat    = "scrap|metal|wood|log|nails|rope|gear|fiber|stone|stick|coal|copper|zinc|iron|sulfur|saltpeter|cement|magnesium|gunpowder|nitrous|acid|duct|tape|cloth|rag|tarp|oil|fat|hide|pelt|thread|needles|line|brass|gunparts|electrical|cable|electronics|circuit|fuse|element|powder|hay|barbwire",
    tool   = "rod|compass|kit|lockpick|padlock|lock|flashlight|lighter|matches|binocular|binos|range|geiger|canteen|bottle|jar|tin|funnel|hose|valve|jack|pump|tire|motor|battery|alternator|compressor|charger|satnav|radio|walkie|microphone|guitar|gamebro|vcr|usb|gpu|hdd|cpu|calculator|clock|alarm|tent|sleepingbag|sewing|repair|drill|measure|spray|heater|stove|thermostat|propane|empty|keycard|hackdevice|letter|att_|carupgrade|money|mech|twinkle|bowl|dogattachment|horsesaddle|jump|powerlead|industrial|can",
}

-- 特殊情况覆盖（分类规则难以处理的）
local CAT_OVERRIDE = {
    FishingRod = "tool", ImproFishingRod = "tool", Rod = "tool",
    WaterBarrel = "tool", GrenadeLauncher = "ranged", PumpkinHoodie = "cloth",
    Watermelon = "food", BasketballBlack = "other", BasketballBlue = "other",
    BasketballWhite = "other", BasketballYellow = "other",
    SVal = "other", Element = "mat", Empty = "other",
}

local function classifyName(name)
    if not name then return CAT_INDEX.other end
    local ov = CAT_OVERRIDE[name]
    if ov then return CAT_INDEX[ov] end
    local lower = name:lower()
    -- 前缀规则
    if name:sub(1, 4) == "Att_" then return CAT_INDEX.tool end
    if name:sub(1, 5) == "SBook" or name:sub(1, 6) == "Charm_" then return CAT_INDEX.other end
    if name:sub(1, 10) == "CarUpgrade" then return CAT_INDEX.tool end
    if lower:sub(1, 4) == "seed" or lower:sub(1, 6) == "packet" then return CAT_INDEX.other end
    for _, id in ipairs({ "ammo", "med", "ranged", "melee", "food", "cloth", "mat", "tool" }) do
        if util.matchAny(name, KEYWORDS[id]) then return CAT_INDEX[id] end
    end
    return CAT_INDEX.other
end

local function classifyTag(tag)
    if not tag then return nil end
    local t = tag:lower()
    if t:find("weapon.ranged", 1, true) or t:find("weapon_range", 1, true) then return CAT_INDEX.ranged end
    if t:find("ammo", 1, true) then return CAT_INDEX.ammo end
    if t:find("treatment", 1, true) or t:find("medical", 1, true) or t:find("medicine", 1, true) then return CAT_INDEX.med end
    if t:find("food", 1, true) or t:find("drink", 1, true) then return CAT_INDEX.food end
    if t:find("clothing", 1, true) or t:find("wearable", 1, true) or t:find("apparel", 1, true) or t:find("armor", 1, true) then return CAT_INDEX.cloth end
    if t:find("resource", 1, true) or t:find("material", 1, true) or t:find("crafting", 1, true) then return CAT_INDEX.mat end
    if t:find("tool", 1, true) then return CAT_INDEX.tool end
    if t:find("weapon.melee", 1, true) or t:find("melee", 1, true) then return CAT_INDEX.melee end
    if t:find("weapon", 1, true) then return CAT_INDEX.melee end
    if t:find("consumable", 1, true) then return CAT_INDEX.food end
    return nil
end

-- ============ 数据存储 ============

items.list = {}
items._byName = {}
items.byCat = {}
items.byCatDirty = true

items.catSel = 1
items.sel = 1
items.scroll = 1
items.PAGE = 12
items.AMOUNTS = { 1, 5, 10, 50, 100 }
items.amountIdx = 1
items.search = "" -- 搜索词（菜单内输入字母/数字实时过滤）

items.cachePath = "Mods\\HTZ_Trainer\\item_cache.txt"
items.scanState = { active = false, done = 0, total = 0 }
items._sampleLogged = false

--- 显示名：中文 + 英文ID
function items.display(name)
    local z = zhMap[name]
    if z and z ~= "" then
        return z .. "  (" .. name .. ")"
    end
    return name
end

function items.amount()
    return items.AMOUNTS[items.amountIdx]
end

function items.cycleAmount(dir)
    items.amountIdx = util.clamp(items.amountIdx + (dir or 1), 1, #items.AMOUNTS)
end

function items.add(name, cat)
    name = util.toString(name) or name
    if type(name) ~= "string" or name == "" then return end
    if items._byName[name] then
        if cat then
            items.list[items._byName[name]].cat = cat
            items.byCatDirty = true
        end
        return
    end
    items.list[#items.list + 1] = { name = name, cat = cat or CAT_INDEX.other }
    items._byName[name] = #items.list
    items.byCatDirty = true
end

function items.setCat(name, cat)
    local idx = items._byName[name]
    if idx and cat then
        items.list[idx].cat = cat
        items.byCatDirty = true
    end
end

function items.rebuild()
    if not items.byCatDirty then return end
    items.byCat = {}
    for i, e in ipairs(items.list) do
        items.byCat[e.cat] = items.byCat[e.cat] or {}
        table.insert(items.byCat[e.cat], i)
    end
    items.byCatDirty = false
end

function items.countOf(catIdx)
    items.rebuild()
    if catIdx == CAT_INDEX.all then return #items.list end
    return #(items.byCat[catIdx] or {})
end

-- ============ 缓存 ============

function items.loadCache()
    local f = io.open(items.cachePath, "r")
    if not f then return 0 end
    local n = 0
    for line in f:lines() do
        local cat, name = line:match("^(%d+)|(.-)%s*$")
        if name and name ~= "" then
            items.add(name, tonumber(cat) or CAT_INDEX.other)
            n = n + 1
        end
    end
    f:close()
    if n > 0 then util.log("物品缓存: 已加载 " .. n .. " 条") end
    return n
end

function items.saveCache()
    local f = io.open(items.cachePath, "w")
    if not f then return end
    for _, e in ipairs(items.list) do
        f:write(string.format("%d|%s\n", e.cat, e.name))
    end
    f:close()
    util.log("物品缓存: 已保存 " .. #items.list .. " 条")
end

function items.loadFallback()
    local ok, list = pcall(require, "data_items")
    if ok and type(list) == "table" then
        for _, n in ipairs(list) do items.add(n, classifyName(n)) end
        util.log("物品: 使用内置回退表 " .. #items.list .. " 条")
    end
end

-- ============ 枚举：方式A - RowMap 属性（安全） ============

local function enumByRowMap(dt)
    local rm = nil
    local ok = pcall(function() rm = dt.RowMap end)
    if not ok or rm == nil then
        util.log("物品枚举(RowMap): 属性不可读")
        return nil
    end
    local ut = nil
    pcall(function() ut = rm:type() end)
    util.log(string.format("物品枚举(RowMap): 类型=%s lua类型=%s", tostring(ut), type(rm)))

    local names = {}
    -- 尝试 ForEach
    local hasForEach = false
    pcall(function() hasForEach = rm.ForEach ~= nil end)
    if hasForEach then
        local n = 0
        pcall(function()
            rm:ForEach(function(k, v)
                local s = util.toString(k)
                if s then names[#names + 1] = s end
                n = n + 1
                if n > 20000 then return true end
            end)
        end)
    end
    -- 尝试把整个 RowMap 当 table 遍历
    if #names == 0 and type(rm) == "table" then
        pcall(function()
            for k, _ in pairs(rm) do
                local s = util.toString(k)
                if s then names[#names + 1] = s end
                if #names > 20000 then break end
            end
        end)
    end
    if #names > 0 then return names end
    return nil
end

--- 导出：运行时枚举 DT_ItemDatabase 全部行名到文件（远程诊断/补齐物品用）
function items.exportLiveRows(path)
    local dt = game.getDT()
    if not util.valid(dt) then return nil, "DT 无效" end
    local names = enumByRowMap(dt)
    if not names then return nil, "RowMap 枚举失败" end
    table.sort(names)
    local f = io.open(path, "w")
    if not f then return nil, "文件写入失败" end
    for _, s in ipairs(names) do
        f:write(s .. "\n")
    end
    f:close()
    return names
end

-- ============ 枚举：方式B - 原生函数（有崩溃风险，需显式许可） ============

local function enumByFunction(dt)
    local allow = io.open("Mods\\HTZ_Trainer\\allow_dtfn.txt", "r")
    if not allow then
        util.log("物品枚举(函数方式): 未启用 allow_dtfn.txt, 跳过")
        return nil
    end
    allow:close()
    local dtl = game.getDTL()
    if not util.valid(dtl) then return nil end
    util.log("物品枚举(函数方式): 调用 GetDataTableRowNames...")
    local out = {}
    local ok, err = pcall(function() dtl:GetDataTableRowNames(dt, out) end)
    if not ok then
        util.log("物品枚举(函数方式)异常: " .. tostring(err))
        return nil
    end
    local names = {}
    pcall(function()
        for _, v in ipairs(out) do
            local s = util.toString(v)
            if s then names[#names + 1] = s end
        end
    end)
    if #names > 0 then return names end
    return nil
end

-- ============ 枚举入口 ============

function items.beginScan()
    -- 安全默认：需要 enable_scan.txt 才启用运行时枚举
    local en = io.open("Mods\\HTZ_Trainer\\enable_scan.txt", "r")
    if not en then
        util.log("物品枚举: 未启用(缺少 enable_scan.txt), 使用内置列表 " .. #items.list .. " 条")
        return false
    end
    en:close()

    util.log("物品枚举步骤: 查找数据表...")
    local dt = game.getDT()
    if not util.valid(dt) then
        util.log("物品枚举: 未找到 DT_ItemDatabase")
        return false
    end

    local names = enumByRowMap(dt)
    local how = "RowMap"
    if not names then
        names = enumByFunction(dt)
        how = "Function"
    end
    if not names or #names == 0 then
        util.log("物品枚举: 所有方式均失败, 保留内置列表")
        return false
    end

    local added = 0
    for _, n in ipairs(names) do
        if not items._byName[n] then
            items.add(n, nil)
            added = added + 1
        end
    end
    items.scanState = { active = true, done = 0, total = #items.list }
    util.log(string.format("物品枚举成功(%s): 表内 %d 行, 新增 %d, 总计 %d", how, #names, added, #items.list))
    items.notify(string.format("物品库: 共 %d 种 (含隐藏物品)", #items.list), false)
    return true
end

--- 每帧分类一小批（游戏线程调用）
function items.scanStep(budget)
    items.checkVerify()
    local st = items.scanState
    if not st.active then return end
    local dt = game.getDT()
    local dtl = game.getDTL()
    if not (util.valid(dt) and util.valid(dtl)) then st.active = false; return end
    budget = budget or 35
    local n = 0
    local i = st.done + 1
    -- 数据驱动分类需显式许可（原生行读取函数属实验特性）
    if items._rowReadAllowed == nil then
        local rf = io.open("Mods\\HTZ_Trainer\\allow_rowread.txt", "r")
        items._rowReadAllowed = rf ~= nil
        if rf then rf:close() end
        util.log("物品分类: 数据驱动=" .. tostring(items._rowReadAllowed) .. " (allow_rowread.txt)")
    end
    while i <= #items.list and n < budget do
        local e = items.list[i]
        if e.cat == CAT_INDEX.other then
            local cat = nil
            if items._rowReadAllowed then
                local out = {}
                local ok = pcall(function() dtl:GetDataTableRowFromName(dt, FName(e.name), out) end)
                if ok and out then
                    if not items._sampleLogged then
                        items._sampleLogged = true
                        local keys = {}
                        pcall(function()
                            for k, _ in pairs(out) do keys[#keys + 1] = tostring(k) end
                        end)
                        util.log("物品行结构体字段: " .. table.concat(keys, ", "))
                    end
                    for _, f in ipairs({ "Classification", "ItemClassification", "ItemType", "Type", "Category", "ItemCategory", "Tags" }) do
                        local v = out[f]
                        if v ~= nil then
                            local s = util.toString(v)
                            if s then
                                cat = classifyTag(s)
                                if cat then break end
                            end
                        end
                    end
                end
            end
            if not cat then cat = classifyName(e.name) end
            e.cat = cat
            items.byCatDirty = true
            n = n + 1
        end
        i = i + 1
        st.done = i
    end
    if st.done >= #items.list then
        st.active = false
        items.saveCache()
        items.rebuild()
        util.log(string.format("物品分类完成: 共 %d 种", #items.list))
        items.notify("物品库扫描完成", false)
    end
end

-- ============ 界面导航 ============

function items.currentFilter()
    items.rebuild()
    -- 搜索模式：全局过滤（匹配英文名或中文名）
    if items.search ~= "" then
        local q = items.search:lower()
        local t = {}
        for i = 1, #items.list do
            local nm = items.list[i].name:lower()
            if nm:find(q, 1, true) then
                t[#t + 1] = i
            else
                local z = zhMap[items.list[i].name]
                if z and z:find(q, 1, true) then t[#t + 1] = i end
            end
        end
        return t
    end
    if items.catSel == CAT_INDEX.all then
        local t = {}
        for i = 1, #items.list do t[i] = i end
        return t
    end
    return items.byCat[items.catSel] or {}
end

function items.openCategory(catIdx)
    items.catSel = catIdx
    items.sel = 1
    items.scroll = 1
    items.search = ""
end

-- ============ 搜索编辑 ============

function items.setSearch(q)
    items.search = q or ""
    items.sel = 1
    items.scroll = 1
end

function items.appendSearch(ch)
    if #items.search >= 16 then return end
    items.setSearch(items.search .. ch)
end

function items.backspaceSearch()
    if items.search == "" then return end
    items.setSearch(items.search:sub(1, #items.search - 1))
end

function items.clearSearch()
    items.setSearch("")
end

function items.current()
    -- sel 为过滤列表中的绝对索引（与 clampView 的维护语义一致）
    local flt = items.currentFilter()
    local idx = flt[items.sel]
    if idx then return items.list[idx].name end
    return nil
end

function items.countFiltered()
    return #items.currentFilter()
end

local function clampView()
    local total = items.countFiltered()
    items.sel = util.clamp(items.sel, 1, math.max(total, 1))
    if items.sel < items.scroll then items.scroll = items.sel end
    if items.sel > items.scroll + items.PAGE - 1 then items.scroll = items.sel - items.PAGE + 1 end
    items.scroll = util.clamp(items.scroll, 1, math.max(total - items.PAGE + 1, 1))
end

function items.move(dir)
    items.sel = items.sel + dir
    clampView()
end

function items.jump(dir)
    items.sel = items.sel + dir * items.PAGE
    clampView()
end

function items.viewRows()
    local flt = items.currentFilter()
    local rows = {}
    for i = 0, items.PAGE - 1 do
        local pos = items.scroll + i
        local idx = flt[pos]
        if not idx then break end
        rows[#rows + 1] = { pos = pos, name = items.list[idx].name, disp = items.display(items.list[idx].name) }
    end
    return rows
end

-- ============ 生成（自动发现调用方式） ============

items._giveMethod = nil
items._fnCache = {}

local GIVE_FN_PATTERN = "additem|addtoinv|giveitem|spawnitem|crafteditem|quickcraft|addweapon|spawnpickup|giveplayer|additemtoslot|addtoquick|addequipment|additemtoequipment|giving"

local STYLE_LIST = {
    { name = "s,a",   fn = function(o, fn, id, am) o[fn](o, id, am) end },
    { name = "F,a",   fn = function(o, fn, id, am) o[fn](o, FName(id), am) end },
    { name = "s,a,b", fn = function(o, fn, id, am) o[fn](o, id, am, true) end },
    { name = "F,a,b", fn = function(o, fn, id, am) o[fn](o, FName(id), am, true) end },
    { name = "s",     fn = function(o, fn, id, am) o[fn](o, id) end },
    { name = "F",     fn = function(o, fn, id, am) o[fn](o, FName(id)) end },
    { name = "a,s",   fn = function(o, fn, id, am) o[fn](o, am, id) end },
}

local function giveTargets()
    return {
        { k = "inv",  obj = game.getInvComp() },
        { k = "pawn", obj = game.getPawn() },
        { k = "pc",   obj = game.getPC() },
    }
end

-- ============ 物品出现验证（重量 / 附近掉落物） ============

local function invWeight()
    local inv = game.getInvComp()
    if not util.valid(inv) then return nil end
    local w = nil
    util.safe(function() w = util.toNumber(inv.CurrentWeight) end)
    return w
end

--- 统计玩家附近掉落物数量（Pickup_Master_C 实例）
local function nearbyPickupCount(radius)
    local pawn = game.getPawn()
    if not util.valid(pawn) then return nil end
    local loc = nil
    util.safe(function() loc = pawn:K2_GetActorLocation() end)
    if loc == nil then return nil end
    local n = 0
    local r2 = (radius or 2000) * (radius or 2000)
    util.safe(function()
        local objs = FindAllOf("Pickup_Master_C")
        if objs then
            for _, o in pairs(objs) do
                if util.valid(o) then
                    local l2 = nil
                    util.safe(function() l2 = o:K2_GetActorLocation() end)
                    if l2 then
                        local dx, dy, dz = l2.X - loc.X, l2.Y - loc.Y, l2.Z - loc.Z
                        if dx * dx + dy * dy + dz * dz < r2 then n = n + 1 end
                    end
                end
            end
        end
    end)
    return n
end

--- 尝试管理面板直刷; 返回 true=调用成功, false+err=失败, nil=不可用
local function tryAdminSpawn(id, amount)
    local pc = game.getGamePC() or game.getPC()
    if not util.valid(pc) then return nil end
    local f = nil
    pcall(function() f = pc["SERVER_Admin_SpawnItem"] end)
    local ft = nil
    if f ~= nil then util.safe(function() ft = f:type() end) end
    if ft ~= "UFunction" then return nil end
    local fname = nil
    util.safe(function() fname = FName(id) end)
    local s = fname and util.toString(fname) or nil
    if not (s and s ~= "None") then return nil end
    local n = util.clamp(tonumber(amount) or 1, 1, 100)
    for _ = 1, n do
        local ok, err = pcall(function() return f(pc, fname) end)
        if not ok then return false, tostring(err) end
    end
    return true
end

--- 开始一次延迟验证（1.5 秒后检查物品是否真的出现）
--- next: 验证失败时的升级方式 ("adminSpawn" 或 nil)
function items.startVerify(id, amount, next_)
    items._verify = {
        id = id,
        amount = amount or 1,
        ["next"] = next_,
        w0 = invWeight(),
        p0 = nearbyPickupCount(2000),
        t0 = os.clock(),
    }
end

--- 由 tick 驱动：完成延迟验证并通知真实结果（失败时自动升级到备用刷法）
function items.checkVerify()
    local v = items._verify
    if not v then return end
    if (os.clock() - v.t0) < 1.5 then return end
    items._verify = nil
    local w1 = invWeight()
    local p1 = nearbyPickupCount(2000)
    local gainedW = (w1 ~= nil and v.w0 ~= nil and w1 > v.w0 + 0.005)
    local gainedP = (p1 ~= nil and v.p0 ~= nil and p1 > v.p0)
    local name = items.display(v.id)
    if gainedW then
        items.notify("已进入背包: " .. name, false)
        return
    end
    if gainedP then
        items.notify("已掉落在面前: " .. name, false)
        return
    end
    -- 未出现 → 自动升级备用刷法
    util.log(string.format("物品验证失败: %s 重量=%s→%s 附近掉落=%s→%s",
        tostring(v.id), tostring(v.w0), tostring(w1), tostring(v.p0), tostring(p1)))
    if v["next"] == "adminSpawn" then
        util.log("升级尝试: 管理面板直刷 SERVER_Admin_SpawnItem")
        local ok = tryAdminSpawn(v.id, v.amount)
        if ok == true then
            items.startVerify(v.id, v.amount, nil)
            return
        end
        util.log("管理面板直刷升级失败: " .. tostring(ok))
    end
    items.notify("物品未出现: " .. name .. " (详见日志)", true)
end

local function collectGiveFns(obj, cacheKey)
    if items._fnCache[cacheKey] then return items._fnCache[cacheKey] end
    local out = {}
    local cls = nil
    util.safe(function() cls = obj:GetClass() end)
    if util.valid(cls) then
        util.safe(function()
            cls:ForEachFunction(function(fnObj)
                local nm = nil
                util.safe(function() nm = fnObj:GetFName():ToString() end)
                if nm and util.matchAny(nm, GIVE_FN_PATTERN) then
                    out[#out + 1] = nm
                end
            end)
        end)
    end
    items._fnCache[cacheKey] = out
    return out
end

--- 已知可用方法（SDK转储 + 多次实测确认）: ForceQuickCraft(FString, int32)
local KNOWN_METHOD = { tk = "inv", fn = "ForceQuickCraft", si = 1 }

local function styleIndexByName(name)
    for i, st in ipairs(STYLE_LIST) do
        if st.name == name then return i end
    end
    return nil
end

--- 尝试一个方法；返回 true=成功, false=失败, nil=目标/函数不可用(跳过)
-- 黑名单：ForceQuickCraft/QuickCraft 只是"排队制作"（PendingQuickCraftCount），并不直刷物品
local FN_BLACKLIST = { ForceQuickCraft = true, QuickCraft = true }

local function tryMethod(m, id, amount)
    if FN_BLACKLIST[m.fn] then return nil end
    local tgt = nil
    for _, t in ipairs(giveTargets()) do
        if t.k == m.tk and util.valid(t.obj) then tgt = t.obj end
    end
    if not tgt then return nil end
    -- 函数存在性检查（防止调用"空包装器"产生假失败/假成功）
    local fnObj = nil
    pcall(function() fnObj = tgt[m.fn] end)
    if fnObj == nil then return nil end
    local ftype = nil
    util.safe(function() ftype = fnObj:type() end)
    if ftype ~= "UFunction" then return nil end
    local st = STYLE_LIST[m.si]
    if not st then return nil end
    local ok = pcall(st.fn, tgt, m.fn, id, amount)
    return ok and true or false
end

--- 自动获取物品生成方式：缓存 → 已知方法/持久化方法 → 全量探测
function items.autoGive(id, amount, report)
    amount = amount or items.amount()
    if not id then return false, "未选中物品" end
    if not game.getPawn() then return false, "未找到玩家" end

    local function rep(s)
        if report then util.log(s) end
    end

    local function okMsg()
        return true, string.format("已生成: %s ×%d", id, amount)
    end

    -- ===== 0) 原生直刷（SERVER_SpawnPickup / SERVER_Admin_SpawnItem）=====
    local pc = game.getGamePC() or game.getPC()
    if util.valid(pc) then
        local fname = nil
        util.safe(function() fname = FName(id) end)
        local nameStr = fname and util.toString(fname) or nil
        if nameStr and nameStr ~= "None" then
            local n = util.clamp(tonumber(amount) or 1, 1, 100)

            -- 方式A: SERVER_SpawnPickup(FName ID, int32 Count, PlayerState PS) —— 原生掉落
            local fA = nil
            pcall(function() fA = pc["SERVER_SpawnPickup"] end)
            local tA = nil
            if fA ~= nil then util.safe(function() tA = fA:type() end) end
            if tA == "UFunction" then
                local ps = nil
                util.safe(function() ps = pc.PlayerState end)
                if util.valid(ps) then
                    items.startVerify(id, n, "adminSpawn")
                    local ok, err = pcall(function() return fA(pc, fname, n, ps) end)
                    if ok then
                        rep(string.format("原生直刷: SERVER_SpawnPickup(%s, %d) (等待验证)", nameStr, n))
                        return true, string.format("已生成: %s ×%d", id, n)
                    end
                    items._verify = nil
                    rep("SERVER_SpawnPickup 失败: " .. tostring(err))
                else
                    rep("SERVER_SpawnPickup: PlayerState 无效")
                end
            end

            -- 方式B: 管理面板 SERVER_Admin_SpawnItem(FName)
            local rB, errB = tryAdminSpawn(id, amount)
            if rB == true then
                items.startVerify(id, n, nil)
                rep(string.format("管理面板直刷: SERVER_Admin_SpawnItem(%s) ×%d (等待验证)", nameStr, n))
                return true, string.format("已生成: %s ×%d", id, n)
            elseif rB == false then
                rep("SERVER_Admin_SpawnItem 失败: " .. tostring(errB))
            end
        else
            rep("物品名不在名称池(FName=None): " .. tostring(id))
        end
    end

    -- 1) 会话缓存
    if items._giveMethod then
        local r = tryMethod(items._giveMethod, id, amount)
        if r then return okMsg() end
        items._giveMethod = nil
    end

    -- 2) 已知方法 + 上次会话持久化的方法（免探测，秒发）
    local candidates = { KNOWN_METHOD }
    local saved = config.get("give_method")
    if saved and saved ~= "" then
        local tk, fn, sn = saved:match("^([^|]+)|([^|]+)|([^|]+)$")
        local si = sn and styleIndexByName(sn)
        if tk and fn and si and not FN_BLACKLIST[fn] then
            local dup = (tk == KNOWN_METHOD.tk and fn == KNOWN_METHOD.fn and si == KNOWN_METHOD.si)
            if not dup then table.insert(candidates, 1, { tk = tk, fn = fn, si = si }) end
        end
    end
    for _, m in ipairs(candidates) do
        local r = tryMethod(m, id, amount)
        if r then
            items._giveMethod = m
            return okMsg()
        end
    end

    -- 3) 全量探测（兜底）
    local attempts = 0
    local capped = false
    for _, t in ipairs(giveTargets()) do
        if util.valid(t.obj) then
            for _, fn in ipairs(collectGiveFns(t.obj, t.k)) do
                if not FN_BLACKLIST[fn] then
                    for si, st in ipairs(STYLE_LIST) do
                        attempts = attempts + 1
                        if attempts > 120 then
                            capped = true
                            break
                        end
                        local ok, err = pcall(st.fn, t.obj, fn, id, amount)
                        if ok then
                            items._giveMethod = { tk = t.k, fn = fn, si = si }
                            config.set("give_method", t.k .. "|" .. fn .. "|" .. st.name)
                            config.save()
                            rep(string.format("物品生成成功: %s.%s 风格=%s (已持久化)", t.k, fn, st.name))
                            return okMsg()
                        else
                            rep(string.format("试 %s.%s(%s) 失败: %s", t.k, fn, st.name, tostring(err)))
                        end
                    end
                end
                if capped then break end
            end
        end
        if capped then break end
    end
    if capped then rep("注意: 达到尝试上限, 已停止探测") end
    return false, string.format("物品生成失败(%d种方式均无效, 详见日志)", attempts)
end

function items.give(id, amount)
    id = id or items.current()
    if not id then
        items.notify("未选中物品", true)
        return false
    end
    local ok, msg = items.autoGive(id, amount or items.amount(), true)
    if items._verify then return ok end -- 结果稍后由延迟验证通知
    items.notify(msg, not ok)
    return ok
end

function items.giveSelected()
    return items.give(items.current(), items.amount())
end

-- 初始化：缓存 → 回退表
if items.loadCache() == 0 then
    items.loadFallback()
end

return items
