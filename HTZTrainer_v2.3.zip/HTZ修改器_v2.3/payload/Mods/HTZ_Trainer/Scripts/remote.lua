-- HTZ Trainer - 本地指令通道（调试/校准用）
-- 通过写 Mods/HTZ_Trainer/cmd.txt（单行 "命令 参数1 参数2"）下发给运行中的游戏
-- 执行结果写入 cmd_out.txt
local util = require("util")

local remote = {}
remote.mods = {} -- main 注入

remote.CMD = "Mods\\HTZ_Trainer\\cmd.txt"
remote.OUT = "Mods\\HTZ_Trainer\\cmd_out.txt"

local handlers = {}

local function writeOut(text)
    local f = io.open(remote.OUT, "w")
    if f then
        f:write(text or "")
        f:close()
    end
end

handlers.ping = function()
    writeOut("pong " .. os.date("%H:%M:%S"))
end

handlers.state = function()
    local m = remote.mods
    local lines = {}
    table.insert(lines, "ready=" .. tostring(m.overlay and m.overlay.ready))
    table.insert(lines, "calibrated=" .. tostring(m.stats and m.stats.calibrated))
    table.insert(lines, "calibNote=" .. tostring(m.stats and m.stats.calibNote))
    table.insert(lines, "items=" .. tostring(m.items and #m.items.list))
    if m.items and m.items.scanState then
        table.insert(lines, string.format("scan=%s %d/%d", tostring(m.items.scanState.active),
            m.items.scanState.done or 0, m.items.scanState.total or 0))
    end
    if m.stats then
        table.insert(lines, string.format("values: HP=%s STA=%s FOOD=%s WATER=%s INF=%s TEMP=%s BATT=%s",
            tostring(m.stats.values.health), tostring(m.stats.values.stamina),
            tostring(m.stats.values.hunger), tostring(m.stats.values.thirst),
            tostring(m.stats.values.infection), tostring(m.stats.values.temperature),
            tostring(m.stats.values.battery)))
    end
    local pawn = m.game and m.game.getPawn()
    table.insert(lines, "pawn=" .. (util.valid(pawn) and pawn:GetFullName() or "none"))
    writeOut(table.concat(lines, "\n"))
end

--- 转储界面对象（主菜单等）的函数
handlers.dumpmenu = function(arg)
    local m = remote.mods
    local game = m.game
    local names = arg and arg ~= "" and arg or "UI_Main_C"
    local out = {}
    local found = false
    for _, clsName in ipairs({ names, "BP_PlayerControllerMenu_C", "BP_GameModeMenu_C", "W_PlayerHUD_C" }) do
        local objs = FindAllOf(clsName)
        if objs then
            for i, o in ipairs(objs) do
                if i <= 2 and util.valid(o) then
                    found = true
                    table.insert(out, "==== 对象 " .. clsName .. " #" .. i .. " " .. o:GetFullName() .. " ====")
                    local cls = o:GetClass()
                    local fns = {}
                    util.safe(function()
                        cls:ForEachFunction(function(fn)
                            local name = nil
                            util.safe(function() name = fn:GetFName():ToString() end)
                            if name and util.matchAny(name, "start|new|continue|load|game|play|host|single|create|menu|quit|click|pressed") then
                                local params = {}
                                util.safe(function()
                                    fn:ForEachProperty(function(p)
                                        local pn = nil
                                        util.safe(function() pn = p:GetFName():ToString() end)
                                        if pn then table.insert(params, pn) end
                                    end)
                                end)
                                table.insert(fns, string.format("  fn %s(%s)", name, table.concat(params, ", ")))
                            end
                        end)
                    end)
                    for _, l in ipairs(fns) do table.insert(out, l) end
                end
            end
        end
    end
    if not found then
        table.insert(out, "未找到菜单对象")
    end
    local text = table.concat(out, "\n")
    if #text > 40000 then text = text:sub(1, 40000) end
    writeOut(text)
end

--- 通用函数转储: dumpobj <类名或路径> [关键词]
handlers.dumpobj = function(arg, arg2)
    local m = remote.mods
    local game = m.game
    local clsName = arg
    if not clsName or clsName == "" then writeOut("用法: dumpobj <类名> [关键词]"); return end
    local obj = FindFirstOf(clsName)
    if not util.valid(obj) and clsName:sub(1, 1) == "/" then
        local ok2, o2 = pcall(StaticFindObject, clsName)
        if ok2 then obj = o2 end
    end
    if not util.valid(obj) then writeOut("未找到对象: " .. clsName); return end
    writeOut("dumping " .. obj:GetFullName() .. " ... 详见 htz_log.txt")
    if arg2 == "" then arg2 = nil end
    util.safe(function()
        game.dumpClass(obj, arg2, 500)
    end)
end

--- 生成物品（自动发现调用方式）: give <物品ID> [数量]
handlers.give = function(a1, a2)
    local m = remote.mods
    local it = m.items
    if not it then writeOut("no items"); return end
    local id = a1
    local amt = tonumber(a2) or 1
    if not id or id == "" then writeOut("用法: give <物品ID> [数量]"); return end
    local ok, msg = it.autoGive(id, amt, true)
    writeOut(string.format("give %s x%d -> %s\n%s", id, amt, tostring(ok), msg))
end

--- 测试文本回退显示（可在无画布时验证菜单可见性）
handlers.textmode = function()
    local m = remote.mods
    local ov = m.overlay
    if ov and ov.renderTextFallback then
        local ok, err = pcall(ov.renderTextFallback)
        writeOut("textmode: " .. tostring(ok) .. " " .. tostring(err))
    else
        writeOut("no overlay.renderTextFallback")
    end
end

--- 尝试动态挂钩真实 HUD 类
handlers.hudhook = function()
    local m = remote.mods
    if m.main and m.main.tryHudHook then
        pcall(m.main.tryHudHook)
        writeOut("hudhook attempted -> 见 htz_log")
    else
        writeOut("no main.tryHudHook")
    end
end

--- 读取当前属性（验证直读模式）
handlers.readstats = function()
    local m = remote.mods
    local S = m.stats
    if not S then writeOut("no stats"); return end
    S.refreshValues()
    local lockBits = {}
    for k, v in pairs(S.locks) do
        if v then lockBits[#lockBits + 1] = k end
    end
    writeOut(string.format(
        "PROPS_OK=%s calibrated=%s note=%s\ngodMode=%s locksOn={%s} anyLockOn=%s\nHP=%s STA=%s FOOD=%s WATER=%s INF=%s TEMP=%s BATT=%s",
        tostring(S.PROPS_OK), tostring(S.calibrated), tostring(S.calibNote),
        tostring(S.godMode), table.concat(lockBits, ","), tostring(S.anyLockOn()),
        tostring(S.values.health), tostring(S.values.stamina),
        tostring(S.values.hunger), tostring(S.values.thirst),
        tostring(S.values.infection), tostring(S.values.temperature),
        tostring(S.values.battery)))
end

--- 开关状态锁定: locks on/off
handlers.locks = function(a1)
    local m = remote.mods
    local S = m.stats
    if not S then writeOut("no stats"); return end
    local on = (a1 == "on")
    S.toggleAllLocks(on)
    writeOut("locks=" .. tostring(on) .. " anyOn=" .. tostring(S.anyLockOn()))
end

--- 直接写一个属性: setstat <key> <value>
handlers.setstat = function(a1, a2)
    local m = remote.mods
    local S = m.stats
    local key = a1
    local val = tonumber(a2)
    if not (S and key and val) then writeOut("用法: setstat <key> <value>"); return end
    local ok = S.write(key, val)
    writeOut(string.format("set %s=%s -> %s", key, tostring(val), tostring(ok)))
end

--- 菜单导航自测: navtest（验证翻页/底部选定一致性）
handlers.navtest = function()
    local m = remote.mods
    local it = m.items
    if not it then writeOut("no items"); return end
    local out = {}
    local function line(s) table.insert(out, s) end
    it.openCategory(1)
    local total = it.countFiltered()
    line("total=" .. total)
    line("start current=" .. tostring(it.current()))
    for _ = 1, 14 do it.move(1) end
    line(string.format("move×14: sel=%d scroll=%d current=%s", it.sel, it.scroll, tostring(it.current())))
    it.jump(1)
    line(string.format("pgdn: sel=%d scroll=%d current=%s", it.sel, it.scroll, tostring(it.current())))
    for _ = 1, 3 do it.jump(1) end
    line(string.format("pgdn×3: sel=%d scroll=%d current=%s", it.sel, it.scroll, tostring(it.current())))
    for _ = 1, 60 do it.jump(1) end
    local found = false
    for _, r in ipairs(it.viewRows()) do
        if r.pos == it.sel then found = true end
    end
    line(string.format("到底部: sel=%d scroll=%d current=%s 高亮行存在=%s", it.sel, it.scroll, tostring(it.current()), tostring(found)))
    it.move(-1)
    line(string.format("上移1: sel=%d scroll=%d current=%s", it.sel, it.scroll, tostring(it.current())))
    it.openCategory(1)
    line("复位: current=" .. tostring(it.current()))
    writeOut(table.concat(out, "\n"))
end

--- 逐名验证物品表真实行（DoesDataTableRowExist）
--- 输入: Mods\HTZ_Trainer\rowcheck_in.txt（每行一个名字）
--- 输出: Mods\HTZ_Trainer\rowcheck_out.txt（OK/NO 前缀）
handlers.rowchk = function()
    local m = remote.mods
    local game = m.game
    local dt = game.getDT()
    local dtl = game.getDTL()
    if not (util.valid(dt) and util.valid(dtl)) then writeOut("DT/DTL 无效"); return end
    local f = nil
    pcall(function() f = dtl["DoesDataTableRowExist"] end)
    local ft = nil
    if f ~= nil then util.safe(function() ft = f:type() end) end
    if ft ~= "UFunction" then writeOut("DoesDataTableRowExist 不可用"); return end
    -- 字符串→FName（find-or-create 路径，规避名称池假阴性）
    local sl = nil
    util.safe(function()
        local okS, o = pcall(StaticFindObject, "/Script/Engine.Default__KismetStringLibrary")
        if okS and util.valid(o) then sl = o end
    end)
    local cf = nil
    if sl ~= nil then util.safe(function() cf = sl["Conv_StringToName"] end) end
    local cft = nil
    if cf ~= nil then util.safe(function() cft = cf:type() end) end
    local inf = io.open("Mods\\HTZ_Trainer\\rowcheck_in.txt", "r")
    if not inf then writeOut("缺少 rowcheck_in.txt"); return end
    local names = {}
    for line in inf:lines() do
        line = line:match("^%s*(.-)%s*$")
        if line ~= "" then names[#names + 1] = line end
    end
    inf:close()
    local out = io.open("Mods\\HTZ_Trainer\\rowcheck_out.txt", "w")
    if not out then writeOut("无法写入 rowcheck_out.txt"); return end
    local okN, noN = 0, 0
    for _, nm in ipairs(names) do
        local fname = nil
        if cft == "UFunction" then
            local okc, ret = pcall(function() return cf(sl, nm) end)
            if okc then fname = ret end
        end
        if fname == nil then
            util.safe(function() fname = FName(nm) end)
        end
        local exists = false
        if fname ~= nil then
            local ok, res = pcall(function() return f(dtl, dt, fname) end)
            if ok and res == true then exists = true end
        end
        if exists then
            okN = okN + 1
            out:write("OK " .. nm .. "\n")
        else
            noN = noN + 1
            out:write("NO " .. nm .. "\n")
        end
    end
    out:close()
    writeOut(string.format("rowchk 完成(ConvStringToName=%s): 有效=%d 无效=%d 共%d",
        tostring(cft), okN, noN, #names))
end

--- 扫描内存中所有 DataTable 实例并测试物品行归属: dtdump
handlers.dtdump = function()
    local m = remote.mods
    local game = m.game
    local out = {}
    local function add(s) table.insert(out, s) end
    local dtl = game.getDTL()
    local f = nil
    if util.valid(dtl) then pcall(function() f = dtl["DoesDataTableRowExist"] end) end
    local ftype = nil
    if f ~= nil then util.safe(function() ftype = f:type() end) end
    add("DoesDataTableRowExist=" .. tostring(ftype))

    -- FName 构造（find-or-create）
    local sl = nil
    util.safe(function()
        local okS, o = pcall(StaticFindObject, "/Script/Engine.Default__KismetStringLibrary")
        if okS and util.valid(o) then sl = o end
    end)
    local cf = nil
    if sl then util.safe(function() cf = sl["Conv_StringToName"] end) end

    local function mkName(s)
        local fn = nil
        if cf then
            local ok, ret = pcall(function() return cf(sl, s) end)
            if ok then fn = ret end
        end
        if fn == nil then util.safe(function() fn = FName(s) end) end
        return fn
    end

    local testNames = { "Apple", "WoodBow", "FuelCan", "SeedCabbage", "NailWoodWeapon", "Arrow", "matches", "MedKit" }

    local n = 0
    util.safe(function()
        local objs = FindAllOf("DataTable")
        if objs then
            for _, o in pairs(objs) do
                if n >= 40 then break end
                if util.valid(o) then
                    local full = nil
                    util.safe(function() full = o:GetFullName() end)
                    if full and full:find("ItemDatabase") then
                        n = n + 1
                        local hits = {}
                        for _, tn in ipairs(testNames) do
                            local fname = mkName(tn)
                            local ex = false
                            if fname then
                                local ok, res = pcall(function() return f(dtl, o, fname) end)
                                if ok and res == true then ex = true end
                            end
                            hits[#hits + 1] = tn .. "=" .. (ex and "1" or "0")
                        end
                        add(string.format("[%d] %s", n, full))
                        add("    " .. table.concat(hits, " "))
                    end
                end
            end
        end
    end)
    if n == 0 then add("(未找到 ItemDatabase 相关 DataTable 实例)") end
    writeOut(table.concat(out, "\n"))
end

--- 读取附近掉落物与背包物品的真实行名（BP侧 FName 直读）: pickdump
handlers.pickdump = function()
    local m = remote.mods
    local game = m.game
    local out = {}
    local function add(s) table.insert(out, s) end
    local SLOT_FIELD = "Item_9_41948ABD452A7B7159035A822EAA304D"

    local function readSlotName(slot)
        -- slot: FS_Slots（脚本结构包装器或远程参数）
        local ok, ret = pcall(function()
            local h = slot[SLOT_FIELD]
            if h == nil then return nil end
            local rn = h.RowName
            if rn == nil then return nil end
            return util.toString(rn)
        end)
        if ok and ret then return ret end
        -- 备用：DataTable/RowName 子字段可能命名不同
        local ok2, ret2 = pcall(function()
            local h = slot[SLOT_FIELD]
            if h == nil then return nil end
            for _, f in ipairs({ "RowName", "RowName_2_", "Row Name" }) do
                local rn = h[f]
                if rn ~= nil then
                    local s = util.toString(rn)
                    if s then return s end
                end
            end
            return nil
        end)
        if ok2 then return ret2 end
        return nil
    end

    local pawn = game.getPawn()
    local loc = nil
    if util.valid(pawn) then util.safe(function() loc = pawn:K2_GetActorLocation() end) end

    -- 1) 附近掉落物
    add("== 附近掉落物 ==")
    local n = 0
    util.safe(function()
        local objs = FindAllOf("Pickup_Master_C")
        if objs then
            for _, o in pairs(objs) do
                if n >= 15 then break end
                if util.valid(o) then
                    local near = false
                    if loc then
                        local l2 = nil
                        util.safe(function() l2 = o:K2_GetActorLocation() end)
                        if l2 then
                            local dx, dy, dz = l2.X - loc.X, l2.Y - loc.Y, l2.Z - loc.Z
                            near = (dx * dx + dy * dy + dz * dz) < 25000000
                        end
                    end
                    if near then
                        n = n + 1
                        local item = nil
                        util.safe(function() item = o.Item end)
                        local nm = item and readSlotName(item) or nil
                        local amt = nil
                        local dtName = nil
                        if item then
                            util.safe(function()
                                local a = item["Amount_12_52EDFED24828CFD8F6F417B8CF707A7D"]
                                if a ~= nil then amt = util.toNumber(a) end
                            end)
                            util.safe(function()
                                local h = item[SLOT_FIELD]
                                if h ~= nil then
                                    local d = h.DataTable
                                    if d ~= nil and util.valid(d) then
                                        dtName = d:GetFullName()
                                    end
                                end
                            end)
                        end
                        add(string.format("掉落: %s x%s (%s) 表=%s", tostring(nm), tostring(amt),
                            o:GetFullName():match("[^%.]+$") or "?", tostring(dtName)))
                    end
                end
            end
        end
    end)
    if n == 0 then add("(200内无掉落物或读取失败)") end

    -- 2) 背包物品
    add("== 背包物品 ==")
    local inv = game.getInvComp()
    if util.valid(inv) then
        local arr = nil
        util.safe(function() arr = inv.inventory end)
        if arr ~= nil then
            local cnt = 0
            util.safe(function()
                arr:ForEach(function(i, elem)
                    if cnt >= 25 then return true end
                    local s = util.unwrap(elem)
                    if s ~= nil then
                        local nm = readSlotName(s)
                        if nm then
                            cnt = cnt + 1
                            add(string.format("背包[%d]: %s", i, nm))
                        end
                    end
                end)
            end)
            if cnt == 0 then add("(背包读取失败或为空)") end
        else
            add("(inventory 属性不可读)")
        end
    else
        add("(无背包组件)")
    end

    writeOut(table.concat(out, "\n"))
end

--- 运行时枚举物品表全行名写入文件: rowscan
handlers.rowscan = function()
    local m = remote.mods
    local it = m.items
    if not (it and it.exportLiveRows) then writeOut("no items.exportLiveRows"); return end
    local names, err = it.exportLiveRows("Mods\\HTZ_Trainer\\item_rows_live.txt")
    if not names then writeOut("rowscan 失败: " .. tostring(err)); return end
    writeOut(string.format("rowscan 完成: %d 行 → item_rows_live.txt", #names))
end

--- 菜单状态: uistate
handlers.uistate = function()
    local m = remote.mods
    local ov = m.overlay
    local S = m.stats
    local it = m.items
    if not ov then writeOut("no overlay"); return end
    writeOut(string.format("open=%s page=%s sel=%s search='%s' god=%s",
        tostring(ov.open), tostring(ov.page), tostring(ov.sel),
        tostring(it and it.search or ""), tostring(S and S.godMode)))
end

--- 背包/掉落物指标: invw（重量、待制作数、附近掉落物数量）
handlers.invw = function()
    local m = remote.mods
    local game = m.game
    local inv = game.getInvComp()
    local w, pend, slots = nil, nil, nil
    if util.valid(inv) then
        util.safe(function() w = util.toNumber(inv.CurrentWeight) end)
        util.safe(function() pend = util.toNumber(inv.PendingQuickCraftCount) end)
        local arr = nil
        util.safe(function() arr = inv.inventory end)
        if arr ~= nil then util.safe(function() slots = arr:GetArrayNum() end) end
    end
    local pawn = game.getPawn()
    local loc = nil
    if util.valid(pawn) then util.safe(function() loc = pawn:K2_GetActorLocation() end) end
    local near = 0
    if loc then
        util.safe(function()
            local objs = FindAllOf("Pickup_Master_C")
            if objs then
                for _, o in pairs(objs) do
                    if util.valid(o) then
                        local l2 = nil
                        util.safe(function() l2 = o:K2_GetActorLocation() end)
                        if l2 then
                            local dx, dy, dz = l2.X - loc.X, l2.Y - loc.Y, l2.Z - loc.Z
                            if dx * dx + dy * dy + dz * dz < 4000000 then near = near + 1 end
                        end
                    end
                end
            end
        end)
    end
    writeOut(string.format("重量=%s 待制作=%s 背包格数=%s 附近掉落物(2000内)=%d", tostring(w), tostring(pend), tostring(slots), near))
end

--- 开关上帝模式并回报实际状态: god on / god off
handlers.god = function(a1)
    local m = remote.mods
    local S = m.stats
    if not S then writeOut("no stats"); return end
    local on = (a1 ~= "off")
    S.setGodMode(on)
    local pawn = m.game.getPawn()
    local flag = nil
    if util.valid(pawn) then
        util.safe(function()
            local v = pawn["GodMode?"]
            if v ~= nil then flag = util.unwrap(v) end
        end)
    end
    writeOut(string.format("godMode=%s 方式=%s 实际标志=%s", tostring(S.godMode),
        tostring(S._godFnUsed), tostring(flag)))
end

--- 生成 SDK 转储（所有类的函数签名）与对象转储
handlers.sdk = function()
    local results = {}
    local function try(name, fn)
        local ok, err = pcall(fn)
        table.insert(results, string.format("%s = %s %s", name, tostring(ok), tostring(err)))
    end
    try("GenerateSDK", function() GenerateSDK() end)
    try("DumpAllObjects", function() DumpAllObjects() end)
    try("DumpUSMAP", function() DumpUSMAP() end)
    writeOut(table.concat(results, "\n"))
end

--- 僵尸生成全矩阵诊断（区分控制器对象/函数存在性/调用错误文本/数量核对）
handlers.spawndiag = function()
    local m = remote.mods
    local game = m.game
    local out = {}
    local function add(s) table.insert(out, s); util.log("[diag] " .. s) end

    local pc = game.getPC()
    local gpc = game.getGamePC()
    add("getPC=" .. (util.valid(pc) and pc:GetFullName() or "nil"))
    add("getGamePC=" .. (util.valid(gpc) and gpc:GetFullName() or "nil"))

    local target = util.valid(gpc) and gpc or pc
    if not util.valid(target) then writeOut(table.concat(out, "\n") .. "\n无控制器"); return end

    -- 函数存在性（UFunction=真实找到, UObject=空包装器即不存在）
    local f = nil
    pcall(function() f = target["SERVER_Admin_SpawnX"] end)
    local ftype = nil
    if f ~= nil then util.safe(function() ftype = f:type() end) end
    add("Admin_SpawnX type=" .. tostring(ftype))
    local fz = nil
    pcall(function() fz = target["SERVER_SpawnZ"] end)
    local fzt = nil
    if fz ~= nil then util.safe(function() fzt = fz:type() end) end
    add("SpawnZ type=" .. tostring(fzt))

    local cls = game.findClass("/Game/TSS_Game/Animations/Zombies/AI/PawnZombie/ZombieClasses/BP_PawnZombie2.BP_PawnZombie2_C")
    add("cls=" .. (util.valid(cls) and "ok" or "nil"))

    local function zcount()
        local n = 0
        util.safe(function()
            local objs = FindAllOf("BP_PawnZombie2_C")
            if objs then
                for _, o in pairs(objs) do
                    local full = nil
                    util.safe(function() full = o:GetFullName() end)
                    if full and not full:find("Default__") and util.valid(o) then n = n + 1 end
                end
            end
        end)
        return n
    end
    local before = zcount()
    add("僵尸计数(前)=" .. tostring(before))

    local pawn = game.getPawn()
    local loc = nil
    if util.valid(pawn) then util.safe(function() loc = pawn:K2_GetActorLocation() end) end
    local base = loc and { X = loc.X, Y = loc.Y, Z = loc.Z + 200 } or { X = 0, Y = 0, Z = 0 }
    local tr = { Translation = base, Rotation = { X = 0, Y = 0, Z = 0, W = 1 }, Scale3D = { X = 1, Y = 1, Z = 1 } }

    if util.valid(cls) and ftype == "UFunction" then
        for i, cb in ipairs({ { 1, false, true, true }, { 1, false, false, false }, { 0, false, false, false }, { 1, true, true, true } }) do
            local ok, err = pcall(function() return f(target, cls, tr, cb[1], cb[2], cb[3], cb[4]) end)
            local now = zcount()
            add(string.format("SpawnX#%d(%d,%s,%s,%s) ok=%s err=%s 僵尸=%d",
                i, cb[1], tostring(cb[2]), tostring(cb[3]), tostring(cb[4]), tostring(ok), tostring(err), now))
            if now > before then add(">>> SERVER_Admin_SpawnX 生成成功"); writeOut(table.concat(out, "\n")); return end
        end
    end

    if fzt == "UFunction" then
        local ok, err = pcall(function() return fz(target) end)
        local now = zcount()
        add(string.format("SpawnZ() ok=%s err=%s 僵尸=%d", tostring(ok), tostring(err), now))
        if now > before then add(">>> SERVER_SpawnZ 生成成功"); writeOut(table.concat(out, "\n")); return end
    end

    local gs = game.gamestat()
    if util.valid(gs) and util.valid(pawn) and util.valid(cls) then
        local ok, res = pcall(function()
            return gs.BeginDeferredActorSpawnFromClass(gs, pawn, cls, tr, 1, nil)
        end)
        add(string.format("BeginDeferred ok=%s res=%s", tostring(ok), tostring(res)))
        if ok and util.valid(res) then
            local ok2, err2 = pcall(function() return gs.FinishSpawningActor(gs, res, tr) end)
            local now = zcount()
            add(string.format("FinishSpawning ok=%s err=%s 僵尸=%d", tostring(ok2), tostring(err2), now))
            if now > before then add(">>> 引擎路线生成成功") end
        end
    else
        add("引擎路线不可用 gs=" .. tostring(util.valid(gs)) .. " pawn=" .. tostring(util.valid(pawn)) .. " cls=" .. tostring(util.valid(cls)))
    end

    writeOut(table.concat(out, "\n"))
end

--- 深度诊断僵尸生成问题（获取真实错误文本+函数对象类型+原生刷怪函数转储）
handlers.probe = function()
    local m = remote.mods
    local game = m.game
    local out = {}
    local function add(s) table.insert(out, s) end

    local gs = game.gamestat()
    local pawn = game.getPawn()
    local cls = game.findClass("/Game/TSS_Game/Animations/Zombies/AI/PawnZombie/ZombieClasses/BP_PawnZombie2.BP_PawnZombie2_C")
    add("gs=" .. tostring(util.valid(gs)) .. " pawn=" .. tostring(util.valid(pawn)) .. " cls=" .. tostring(util.valid(cls)))

    if util.valid(cls) then
        local isClass = nil
        pcall(function() isClass = cls:IsClass() end)
        add("cls:IsClass()=" .. tostring(isClass))
    end

    if util.valid(gs) then
        local f = gs["BeginDeferredActorSpawnFromClass"]
        add("type(gs.BeginDeferred...)=" .. type(f) .. " tostring=" .. tostring(f))
    end

    if util.valid(gs) and util.valid(pawn) and util.valid(cls) then
        local errVal, tr = nil, nil
        local ok = xpcall(function()
            local ml = game.mathlib()
            local loc = pawn:K2_GetActorLocation()
            local tf = ml:MakeTransform({ X = loc.X, Y = loc.Y, Z = loc.Z }, { X = 0, Y = 0, Z = 0 }, { X = 1, Y = 1, Z = 1 })
            return gs:BeginDeferredActorSpawnFromClass(pawn, cls, tf, 1, nil)
        end, function(e)
            errVal = e
            tr = debug.traceback("", 2)
            return e
        end)
        add(string.format("call ok=%s errtype=%s errtostring=%s", tostring(ok), type(errVal), tostring(errVal)))
        if tr then add("traceback:\n" .. tostring(tr):sub(1, 1200)) end
    end

    -- 原生刷怪函数搜索（转储到日志）
    add("转储 pawn/pc/gamestate 的 spawn 相关函数 -> htz_log")
    util.safe(function()
        game.dumpClass(pawn, "spawn|summon|ai|zomb|zeek|create|add", 120)
    end)
    local pc = game.getPC()
    util.safe(function()
        game.dumpClass(pc, "spawn|summon|zomb|zeek|create|debug|admin", 120)
    end)
    local gst = FindFirstOf("BP_GameStateBase_C")
    if util.valid(gst) then
        util.safe(function()
            game.dumpClass(gst, "spawn|summon|zomb|zeek|create|wave|ai", 120)
        end)
    else
        add("BP_GameStateBase_C 实例未找到")
    end
    writeOut(table.concat(out, "\n"))
end

--- 生成车辆测试: vspawn <序号从1开始>
handlers.vspawn = function(a1)
    local m = remote.mods
    local V = m.vehicles
    if not V then writeOut("no vehicles"); return end
    local idx = tonumber(a1) or 1
    local entry = V.data[idx]
    if not entry then writeOut("无效序号 (1-" .. #V.data .. ")"); return end
    local ok, msg = V.spawnOne(entry, true)
    writeOut(string.format("vspawn #%d %s -> %s\n%s", idx, entry.id, tostring(ok), tostring(msg)))
end

--- 搜索测试: search <关键词>
handlers.search = function(a1, a2)
    local m = remote.mods
    local it = m.items
    if not it then writeOut("no items"); return end
    local q = a1
    if a2 and a2 ~= "" then q = q .. " " .. a2 end
    it.setSearch(q or "")
    local n = it.countFiltered()
    local out = { string.format("search '%s' -> %d 项", tostring(q), n) }
    local flt = it.currentFilter()
    for i = 1, math.min(6, #flt) do
        out[#out + 1] = "  " .. it.list[flt[i]].name
    end
    it.setSearch("")
    writeOut(table.concat(out, "\n"))
end

--- 测试僵尸生成（自动发现）: zspawn <序号从1开始>
handlers.zspawn = function(a1)
    local m = remote.mods
    local z = m.zombies
    if not z then writeOut("no zombies"); return end
    local idx = tonumber(a1) or 1
    local entry = z.data[idx]
    if not entry then writeOut("无效序号 (1-" .. #z.data .. ")"); return end
    local ok, msg = z.autoSpawnOne(entry, true)
    writeOut(string.format("zspawn #%d %s -> %s\n%s", idx, entry.id, tostring(ok), tostring(msg)))
end

--- 测试 RowMap 属性枚举（安全路径）
handlers.rows2 = function()
    local m = remote.mods
    local dt = m.game.getDT()
    if not util.valid(dt) then writeOut("dt invalid"); return end
    local out = {}
    local rm = nil
    local ok = pcall(function() rm = dt.RowMap end)
    table.insert(out, "ok=" .. tostring(ok) .. " lua=" .. type(rm))
    if rm ~= nil then
        local ut = nil
        pcall(function() ut = rm:type() end)
        local n = 0
        pcall(function()
            rm:ForEach(function(k, v)
                if n < 8 then table.insert(out, "key[" .. n .. "]=" .. tostring(util.toString(k) or "?")) end
                n = n + 1
                if n > 20000 then return true end
            end)
        end)
        table.insert(out, "type=" .. tostring(ut) .. " total=" .. n)
    end
    writeOut(table.concat(out, "\n"))
end

--- 测试物品行名枚举（受控实验：单独调用一次，观察是否安全）
handlers.testrows = function()
    local m = remote.mods
    local dtl = m.game.getDTL()
    local dt = m.game.getDT()
    if not util.valid(dtl) then writeOut("DataTableFunctionLibrary 无效"); return end
    if not util.valid(dt) then writeOut("DT_ItemDatabase 无效"); return end
    local out = {}
    local ok, err = pcall(function() dtl:GetDataTableRowNames(dt, out) end)
    local n = 0
    pcall(function() for _ in pairs(out) do n = n + 1 end end)
    local sample = ""
    local i = 0
    pcall(function()
        for _, v in ipairs(out) do
            if i >= 5 then break end
            sample = sample .. tostring(v) .. ", "
            i = i + 1
        end
    end)
    writeOut(string.format("ok=%s\nerr=%s\ncount=%d\nsample=%s", tostring(ok), tostring(err), n, sample))
end

--- 转储属性: dumpprops <类名>
handlers.dumpprops = function(arg)
    local m = remote.mods
    local game = m.game
    local clsName = arg
    if not clsName or clsName == "" then writeOut("用法: dumpprops <类名>"); return end
    local obj = FindFirstOf(clsName)
    if not util.valid(obj) and clsName:sub(1, 1) == "/" then
        local ok2, o2 = pcall(StaticFindObject, clsName)
        if ok2 then obj = o2 end
    end
    if not util.valid(obj) then writeOut("未找到对象: " .. clsName); return end
    local cls = nil
    util.safe(function()
        if obj:IsClass() then cls = obj else cls = obj:GetClass() end
    end)
    if not util.valid(cls) then writeOut("类无效"); return end
    local out = { "==== 属性转储: " .. cls:GetFullName() .. " ====" }
    util.safe(function()
        cls:ForEachProperty(function(p)
            local name, info = nil, ""
            util.safe(function() name = p:GetFName():ToString() end)
            util.safe(function()
                if p:IsA(PropertyTypes.MapProperty) then info = "MAP"
                elseif p:IsA(PropertyTypes.ArrayProperty) then info = "ARRAY"
                elseif p:IsA(PropertyTypes.ObjectProperty) then info = "OBJ"
                elseif p:IsA(PropertyTypes.StructProperty) then info = "STRUCT"
                elseif p:IsA(PropertyTypes.FloatProperty) then info = "FLOAT"
                elseif p:IsA(PropertyTypes.IntProperty) then info = "INT"
                elseif p:IsA(PropertyTypes.BoolProperty) then info = "BOOL"
                elseif p:IsA(PropertyTypes.StrProperty) then info = "STR"
                elseif p:IsA(PropertyTypes.ByteProperty) then info = "BYTE"
                elseif p:IsA(PropertyTypes.NameProperty) then info = "NAME"
                elseif p:IsA(PropertyTypes.EnumProperty) then info = "ENUM"
                end
            end)
            if name and util.matchAny(name, "attribute|health|hunger|thirst|stamina|infect|temperature|battery|value|max|drain|update") then
                table.insert(out, string.format("  %s [%s]", name, info))
            end
        end)
    end)
    local text = table.concat(out, "\n")
    if #text > 40000 then text = text:sub(1, 40000) end
    writeOut(text)
end

--- 尝试通过菜单控制器开始游戏（实验性）
handlers.startgame = function()
    local m = remote.mods
    local out = {}
    local objs = FindAllOf("UI_Main_C") or FindAllOf("BP_PlayerControllerMenu_C")
    if not objs then writeOut("未找到菜单对象"); return end
    for _, o in ipairs(objs) do
        for _, fn in ipairs({ "StartGame", "NewGame", "StartNewGame", "StartSingleplayer", "SinglePlayer", "Play", "Start" }) do
            if o[fn] ~= nil then
                local ok, err = pcall(function() o[fn](o) end)
                table.insert(out, string.format("尝试 %s -> %s (%s)", fn, tostring(ok), tostring(err)))
            end
        end
    end
    writeOut(table.concat(out, "\n"))
end

--- 转储属性组件类（无需实例，菜单阶段即可用）
handlers.dumpattr = function(arg)
    local m = remote.mods
    local game = m.game
    local clsPath = (arg and arg ~= "") and arg or "/Game/Coredamage/AttributeComponent/Component/BP_AttributeComponent.BP_AttributeComponent_C"
    local ok, cls = pcall(StaticFindObject, clsPath)
    if not (ok and util.valid(cls)) then writeOut("类未找到: " .. clsPath); return end
    writeOut("dumpattr 结果写入 htz_log.txt")
    util.safe(function()
        game.dumpClass(cls,
            "get|set|update|attribute|value|drain|health|hunger|thirst|stamina|infect|temperature|battery|bleed|heal|vital|stat|consume|food|water|buff|timer|modif|condit|sick|symptom", 400)
    end)
end

local function dispatch(line)
    local cmd, rest = line:match("^(%S+)%s*(.-)%s*$")
    if not cmd then return end
    local h = handlers[cmd]
    if not h then
        writeOut("未知命令: " .. cmd)
        return
    end
    local a1, a2 = rest:match("^(%S+)%s*(.*)$")
    h(a1, a2)
end

function remote.start()
    util.log("指令通道已启动 (cmd.txt)")
    LoopAsync(400, function()
        local f = io.open(remote.CMD, "r")
        if f then
            local line = f:read("*l")
            f:close()
            os.remove(remote.CMD)
            if line and line ~= "" then
                util.log("收到远程指令: " .. line)
                util.inGame(function()
                    local ok, err = pcall(dispatch, line)
                    if not ok then
                        writeOut("指令异常: " .. tostring(err))
                    end
                end)
            end
        end
        return false
    end)
end

return remote
