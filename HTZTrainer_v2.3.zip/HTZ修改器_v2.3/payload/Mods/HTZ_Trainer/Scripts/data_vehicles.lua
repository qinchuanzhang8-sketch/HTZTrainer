-- 车辆清单（游戏内 DrivableVehicles 全量，路径已按资产表确认）
local base = "/Game/TSS_Game/Blueprints/Vehicles/Possession/Blueprints/DrivableVehicles/"
local list = {
    { id = "BP_Jeep",               cn = "吉普车",           en = "Jeep" },
    { id = "BP_JeepArmy",           cn = "军用吉普",         en = "Army Jeep" },
    { id = "BP_JeepPolice",         cn = "警用吉普",         en = "Police Jeep" },
    { id = "BP_Pickup",             cn = "皮卡",             en = "Pickup" },
    { id = "BP_PickupTruckBlack",   cn = "黑色皮卡",         en = "Black Pickup" },
    { id = "BP_PickupTruckRed",     cn = "红色皮卡",         en = "Red Pickup" },
    { id = "BP_Pickup_White",       cn = "白色皮卡",         en = "White Pickup" },
    { id = "BP_SUV",                cn = "SUV",              en = "SUV" },
    { id = "BP_SUV_01",             cn = "SUV·01",           en = "SUV 01" },
    { id = "BP_OffRoadSUV",         cn = "越野SUV",          en = "Off-road SUV" },
    { id = "BP_PoliceSUV",          cn = "警用SUV",          en = "Police SUV" },
    { id = "BP_SecuritySUV",        cn = "安保SUV",          en = "Security SUV" },
    { id = "BP_StorageSUV",         cn = "储物SUV",          en = "Storage SUV" },
    { id = "BP_Sedane01",           cn = "轿车",             en = "Sedan" },
    { id = "BP_Hatchback",          cn = "掀背车",           en = "Hatchback" },
    { id = "BP_Hatch01",            cn = "掀背车·01",        en = "Hatch 01" },
    { id = "BP_Hatchback308",       cn = "308掀背车",        en = "Hatchback 308" },
    { id = "BP_Hatchback308_Black", cn = "308掀背车·黑",     en = "308 Black" },
    { id = "BP_Hatchback308_Blue",  cn = "308掀背车·蓝",     en = "308 Blue" },
    { id = "BP_SportCar",           cn = "跑车",             en = "Sport Car" },
    { id = "BP_SportCarBlack",      cn = "黑色跑车",         en = "Black Sport Car" },
    { id = "BP_SportCarYellow",     cn = "黄色跑车",         en = "Yellow Sport Car" },
    { id = "BP_Amero",              cn = "阿梅罗跑车",       en = "Amero" },
    { id = "BP_LevyLazer",          cn = "莱维跑车",         en = "Levy Lazer" },
    { id = "BP_LevyLazer_Storage",  cn = "莱维跑车·储物版",  en = "Levy Lazer Storage" },
    { id = "BP_AUGH",               cn = "奥格跑车",         en = "AUGH" },
    { id = "BP_RallyCar",           cn = "拉力赛车",         en = "Rally Car" },
    { id = "BP_GAZTiger",           cn = "虎式装甲车",       en = "GAZ Tiger" },
    { id = "BP_Rhino",              cn = "犀牛装甲车",       en = "Rhino" },
    { id = "BP_Van",                cn = "面包车",           en = "Van" },
    { id = "BP_Van_Red",            cn = "红色面包车",       en = "Red Van" },
    { id = "BP_Van_White",          cn = "白色面包车",       en = "White Van" },
    { id = "BP_Van_Halloween",      cn = "万圣节面包车",     en = "Halloween Van" },
    { id = "BP_SmallVan",           cn = "小型货车",         en = "Small Van" },
    { id = "BP_SmallVan_Blue",      cn = "蓝色小型货车",     en = "Blue Small Van" },
    { id = "BP_BoxVan",             cn = "厢式货车",         en = "Box Van" },
    { id = "BP_Campervan",          cn = "房车",             en = "Campervan" },
    { id = "BP_Truck",              cn = "卡车",             en = "Truck" },
}

local out = {}
for _, e in ipairs(list) do
    e.path = base .. e.id .. "." .. e.id .. "_C"
    out[#out + 1] = e
end
return out
