-- HTZ Trainer - 车辆生成器（SERVER_SpawnCar 原生函数）
local util = require("util")
local game = require("game")

local vehicles = {}

vehicles.notify = function(msg, isErr) end

vehicles.data = require("data_vehicles")
vehicles.sel = 1
vehicles.scroll = 1
vehicles.PAGE = 12
vehicles.dist = 500 -- 生成距离（厘米级）

function vehicles.current()
    return vehicles.data[vehicles.sel]
end

function vehicles.move(dir)
    vehicles.sel = util.clamp(vehicles.sel + dir, 1, #vehicles.data)
    if vehicles.sel < vehicles.scroll then vehicles.scroll = vehicles.sel end
    if vehicles.sel > vehicles.scroll + vehicles.PAGE - 1 then vehicles.scroll = vehicles.sel - vehicles.PAGE + 1 end
end

function vehicles.jump(dir)
    vehicles.sel = util.clamp(vehicles.sel + dir * vehicles.PAGE, 1, #vehicles.data)
    if vehicles.sel < vehicles.scroll then vehicles.scroll = vehicles.sel end
    if vehicles.sel > vehicles.scroll + vehicles.PAGE - 1 then vehicles.scroll = vehicles.sel - vehicles.PAGE + 1 end
end

function vehicles.cycleDist(dir)
    vehicles.dist = util.clamp(vehicles.dist + dir * 100, 200, 1500)
end

function vehicles.viewRows()
    local rows = {}
    for i = 0, vehicles.PAGE - 1 do
        local idx = vehicles.scroll + i
        if idx > #vehicles.data then break end
        rows[#rows + 1] = { idx = idx, entry = vehicles.data[idx] }
    end
    return rows
end

local function countClass(name)
    local n = 0
    util.safe(function()
        local objs = FindAllOf(name)
        if objs then
            for _, o in pairs(objs) do
                local full = nil
                util.safe(function() full = o:GetFullName() end)
                if full and not full:find("Default__") and util.valid(o) then n = n + 1 end
            end
        end
    end)
    return n
end

--- 生成一辆车: pc:SERVER_SpawnCar(Class, PlayerState, Distance)
function vehicles.spawnOne(entry, report)
    local pawn = game.getPawn()
    if not util.valid(pawn) then return false, "未找到玩家" end
    local pc = game.getGamePC() or game.getPC()
    if not util.valid(pc) then return false, "未找到游戏内控制器" end
    local cls = game.findClass(entry.path)
    if not util.valid(cls) then
        util.safe(function() ExecuteInGameThread(function() LoadAsset(entry.path) end) end)
        cls = game.findClass(entry.path)
    end
    if not util.valid(cls) then
        -- 资源尚未加载：触发加载并提示稍后重试
        return false, "车辆资源加载中，请稍等 1-2 秒后再生成一次"
    end
    local ps = nil
    util.safe(function() ps = pc.PlayerState end)
    if not util.valid(ps) then return false, "PlayerState 无效" end
    local f = nil
    pcall(function() f = pc["SERVER_SpawnCar"] end)
    local ft = nil
    if f ~= nil then util.safe(function() ft = f:type() end) end
    if ft ~= "UFunction" then return false, "SERVER_SpawnCar 不可用" end

    local clsName = entry.id .. "_C"
    local before = nil
    if report then before = countClass(clsName) end
    local ok, err = pcall(function() return f(pc, cls, ps, vehicles.dist) end)
    if not ok then
        util.log("SERVER_SpawnCar 失败: " .. tostring(err))
        return false, "调用失败(详见日志)"
    end
    if report then
        local after = countClass(clsName)
        util.log(string.format("车辆生成: %s 数量 %s→%s (距离%d)", entry.id, tostring(before), tostring(after), vehicles.dist))
        if after <= (before or 0) then
            return false, "调用成功但计数未变(可能距离原因)"
        end
    end
    return true, "已生成车辆: " .. entry.cn
end

function vehicles.spawn()
    local entry = vehicles.current()
    if not entry then return false end
    local ok, msg = vehicles.spawnOne(entry, true)
    vehicles.notify(msg, not ok)
    return ok
end

--- 启动时后台预加载全部车辆资源（每 250ms 加载一个，避免卡顿）
function vehicles.preload()
    local i = 0
    LoopAsync(250, function()
        i = i + 1
        if i > #vehicles.data then
            util.log("车辆资源预加载完成")
            return true
        end
        local e = vehicles.data[i]
        util.inGame(function()
            if not util.valid(game.findClass(e.path)) then
                util.safe(function() LoadAsset(e.path) end)
            end
        end)
        return false
    end)
end

return vehicles
