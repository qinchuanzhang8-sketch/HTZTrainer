-- HTZ Trainer v1.1 - 工具库
-- 日志 / 安全调用 / 包装解包 / 主线程执行
local util = {}

util.LOG_PATH = "Mods\\HTZ_Trainer\\htz_log.txt"
util._logFile = nil

local function getLogFile()
    if util._logFile then return util._logFile end
    local f = io.open(util.LOG_PATH, "a")
    if f then util._logFile = f end
    return f
end

function util.log(msg)
    local line = string.format("[HTZ][%s] %s", os.date("%H:%M:%S"), tostring(msg))
    print(line .. "\n")
    local f = getLogFile()
    if f then
        f:write(string.format("[%s] %s\n", os.date("%Y-%m-%d %H:%M:%S"), tostring(msg)))
        f:flush()
    end
end

function util.safe(fn, ...)
    local ok, ret = pcall(fn, ...)
    if not ok then return false, tostring(ret) end
    return true, ret
end

--- 调试日志（仅写入文件，不刷控制台）
function util.debug(msg)
    local f = getLogFile()
    if f then
        f:write(string.format("[%s][debug] %s\n", os.date("%Y-%m-%d %H:%M:%S"), tostring(msg)))
        f:flush()
    end
end

--- 在游戏主线程执行（所有对游戏对象的操作必须走这里，否则会闪退）
function util.inGame(fn)
    local ok = pcall(function()
        ExecuteInGameThread(function()
            local ok2, err = pcall(fn)
            if not ok2 then
                util.log("主线程任务异常: " .. tostring(err))
            end
        end)
    end)
    if not ok then util.log("ExecuteInGameThread 调用失败") end
end

--- 解包 UE4SS 包装对象
local function unwrapInner(v)
    if v == nil then return nil end
    local t = type(v)
    if t == "number" or t == "string" or t == "boolean" then return v end
    if t == "userdata" or t == "table" then
        local ut = nil
        util.safe(function() ut = v:type() end)
        if ut == "RemoteUnrealParam" or ut == "LocalUnrealParam" then
            local inner = nil
            util.safe(function() inner = v:get() end)
            return unwrapInner(inner)
        end
        if ut == "FName" or ut == "FString" or ut == "FText" then
            local s = nil
            util.safe(function() s = v:ToString() end)
            if s ~= nil then return s end
        end
        return v
    end
    return v
end

function util.unwrap(v)
    return unwrapInner(v)
end

--- 解包成数字
function util.toNumber(v)
    v = unwrapInner(v)
    if type(v) == "number" then return v end
    if type(v) == "string" then return tonumber(v) end
    -- 结构体表（如 GameplayTag{TagName=...}）不转数字
    return nil
end

--- 解包成字符串（FName/FString/GameplayTag 结构体均可）
function util.toString(v)
    v = unwrapInner(v)
    if type(v) == "string" then return v end
    if type(v) == "number" then return tostring(v) end
    if type(v) == "table" or type(v) == "userdata" then
        -- 尝试 TagName 字段（GameplayTag）
        local tn = nil
        util.safe(function() tn = v.TagName end)
        if tn ~= nil and tn ~= v then return util.toString(tn) end
    end
    return nil
end

function util.valid(obj)
    if obj == nil then return false end
    local ok, res = pcall(function() return obj:IsValid() end)
    return ok and res == true
end

function util.round(n, digits)
    digits = digits or 0
    local m = 10 ^ digits
    return math.floor(n * m + 0.5) / m
end

function util.clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end

--- 关键词匹配（正确支持 a|b|c 语法，杜绝 Lua 模式误用）
function util.matchAny(text, patterns)
    if not text then return false end
    local lower = text:lower()
    for p in tostring(patterns):gmatch("[^|]+") do
        if lower:find(p:lower(), 1, true) then return true end
    end
    return false
end

return util
