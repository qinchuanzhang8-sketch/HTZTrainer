-- HTZ Trainer v1.1.3 - 僵尸/怪物生成器（自动发现生成方式）
local util = require("util")
local game = require("game")
local config = require("config")

local zombies = {}

zombies.notify = function(msg, isErr) end

zombies.data = require("data_zombies")
zombies.COUNTS = { 1, 3, 5, 10, 20 }
zombies.countIdx = 1
zombies.sel = 1
zombies.scroll = 1
zombies.PAGE = 12

zombies._spawnMethod = nil

function zombies.count()
    return zombies.COUNTS[zombies.countIdx]
end

function zombies.cycleCount(dir)
    zombies.countIdx = util.clamp(zombies.countIdx + (dir or 1), 1, #zombies.COUNTS)
end

function zombies.current()
    return zombies.data[zombies.sel]
end

function zombies.move(dir)
    zombies.sel = util.clamp(zombies.sel + dir, 1, #zombies.data)
    if zombies.sel < zombies.scroll then zombies.scroll = zombies.sel end
    if zombies.sel > zombies.scroll + zombies.PAGE - 1 then zombies.scroll = zombies.sel - zombies.PAGE + 1 end
end

function zombies.jump(dir)
    zombies.sel = util.clamp(zombies.sel + dir * zombies.PAGE, 1, #zombies.data)
    if zombies.sel < zombies.scroll then zombies.scroll = zombies.sel end
    if zombies.sel > zombies.scroll + zombies.PAGE - 1 then zombies.scroll = zombies.sel - zombies.PAGE + 1 end
end

function zombies.viewRows()
    local rows = {}
    for i = 0, zombies.PAGE - 1 do
        local idx = zombies.scroll + i
        if idx > #zombies.data then break end
        rows[#rows + 1] = { idx = idx, entry = zombies.data[idx] }
    end
    return rows
end

-- ============ 工具 ============

local function V(x, y, z) return { X = x, Y = y, Z = z } end

local function vecTable(v)
    local ok, x = pcall(function() return v.X end)
    if not ok or x == nil then return nil end
    local y = v.Y or 0
    local z = v.Z or 0
    return V(x, y, z)
end

-- 生成位置：玩家前方
local function spawnPoints()
    local pawn = game.getPawn()
    if not util.valid(pawn) then return nil end
    local dist = tonumber(config.get("spawn_dist")) or 650
    local loc = vecTable(pawn:K2_GetActorLocation())
    local fwd = vecTable(pawn:GetActorForwardVector())
    if not loc or not fwd then return nil end
    local p = V(loc.X + fwd.X * dist, loc.Y + fwd.Y * dist, loc.Z + 30)
    return p, V(0, 0, 0)
end

-- ============ 生成（原生管理函数优先 + 引擎兜底） ============

--- 统计指定类僵尸数量（排除CDO）
local function countClass(className)
    local n = 0
    util.safe(function()
        local objs = FindAllOf(className)
        if objs then
            for _, o in pairs(objs) do
                local full = nil
                util.safe(function() full = o:GetFullName() end)
                if full and not full:find("Default__") and util.valid(o) then n = n + 1 end
            end
        end
    end)
    return n
end

--- 尝试生成一只；返回 ok, 描述
--- 原生签名（SDK转储确认）:
---   SERVER_Admin_SpawnX(TSubclassOf<AActor> Class, FTransform Tr,
---                       ESpawnActorCollisionHandlingMethod CollisionHandlingOverride,
---                       bool UseEQS?, bool Forced?, bool AdminP?)
--- 注意: UE4SS 调用约定 = 点语法 + 显式self + 精确参数个数（一个不多一个不少）
function zombies.autoSpawnOne(entry, report)
    local pawn = game.getPawn()
    if not util.valid(pawn) then
        return false, "未找到玩家"
    end
    -- 就绪守卫：主菜单阶段的 DefaultPawn 无法承载刷怪
    local pawnCls = nil
    util.safe(function() pawnCls = pawn:GetClass():GetFName():ToString() end)
    if pawnCls and not pawnCls:find("Character") then
        return false, "游戏尚未就绪（请进入游戏后再试）"
    end
    local cls = game.findClass(entry.path)
    if not util.valid(cls) then
        util.safe(function()
            ExecuteInGameThread(function() LoadAsset(entry.path) end)
        end)
        cls = game.findClass(entry.path)
    end
    if not util.valid(cls) then
        return false, "未找到怪物类: " .. entry.id
    end

    local pos, rot = spawnPoints()
    if not pos then return false, "位置计算失败" end

    local function rep(s)
        if report then util.log(s) end
    end

    -- 刷怪点回退链：前方650 → 前方300 → 头顶200 → 脚下（游戏内部对落点有校验，逐个尝试）
    local loc, fwd = nil, nil
    util.safe(function() loc = vecTable(pawn:K2_GetActorLocation()) end)
    util.safe(function() fwd = vecTable(pawn:GetActorForwardVector()) end)
    local spots = { { name = "前方650", t = pos } }
    if loc then
        local fx = fwd and fwd.X or 0
        local fy = fwd and fwd.Y or 0
        spots[#spots + 1] = { name = "前方300", t = V(loc.X + fx * 300, loc.Y + fy * 300, loc.Z + 50) }
        spots[#spots + 1] = { name = "头顶200", t = V(loc.X, loc.Y, loc.Z + 200) }
        spots[#spots + 1] = { name = "脚下",   t = V(loc.X, loc.Y, loc.Z + 10) }
    end

    local className = entry.id .. "_C"
    local before = nil
    if report then before = countClass(className) end
    local function grew()
        if not report then return true end
        return countClass(className) > (before or 0)
    end

    -- ===== 首选：管理面板同款原生刷怪函数 =====
    local pc = game.getGamePC() or game.getPC()
    if report then
        rep("刷怪调试: pc=" .. (util.valid(pc) and pc:GetFullName() or "nil"))
        if loc then
            rep(string.format("刷怪调试: loc=%.0f,%.0f,%.0f fwd=%.2f,%.2f,%.2f",
                loc.X, loc.Y, loc.Z, fwd and fwd.X or 0, fwd and fwd.Y or 0, fwd and fwd.Z or 0))
        end
    end
    if util.valid(pc) then
        local f = nil
        pcall(function() f = pc["SERVER_Admin_SpawnX"] end)
        local ftype = nil
        if f ~= nil then util.safe(function() ftype = f:type() end) end
        if ftype == "UFunction" then
            -- 组合顺序：(1,f,f,f) 实测成功组合优先
            local combos = {}
            if zombies._nativeCombo then combos[#combos + 1] = zombies._nativeCombo end
            for _, cb in ipairs({ { 1, false, false, false }, { 1, false, true, true }, { 0, false, false, false } }) do
                local dup = false
                for _, t in ipairs(combos) do
                    if t[1] == cb[1] and t[2] == cb[2] and t[3] == cb[3] and t[4] == cb[4] then dup = true end
                end
                if not dup then combos[#combos + 1] = cb end
            end
            for _, sp in ipairs(spots) do
                local tr = { Translation = sp.t, Rotation = { X = 0, Y = 0, Z = 0, W = 1 }, Scale3D = V(1, 1, 1) }
                for _, cb in ipairs(combos) do
                    local ok, err = pcall(function()
                        return f(pc, cls, tr, cb[1], cb[2], cb[3], cb[4])
                    end)
                    if ok and grew() then
                        zombies._nativeCombo = cb
                        rep(string.format("原生生成成功 SERVER_Admin_SpawnX(%d,%s,%s,%s) 落点=%s",
                            cb[1], tostring(cb[2]), tostring(cb[3]), tostring(cb[4]), sp.name))
                        return true, "已生成"
                    else
                        rep(string.format("试 SERVER_Admin_SpawnX(%d,%s,%s,%s)@%s %s: %s",
                            cb[1], tostring(cb[2]), tostring(cb[3]), tostring(cb[4]), sp.name,
                            ok and "调用成功但未生成" or "失败", tostring(err)))
                    end
                end
            end
        else
            rep("SERVER_Admin_SpawnX 不可用 (type=" .. tostring(ftype) .. ") pc=" ..
                (util.valid(pc) and pc:GetFullName() or "nil"))
        end

        -- 备用：SERVER_SpawnZ（无参）
        local fz = nil
        pcall(function() fz = pc["SERVER_SpawnZ"] end)
        local fzt = nil
        if fz ~= nil then util.safe(function() fzt = fz:type() end) end
        if fzt == "UFunction" then
            local ok, err = pcall(function() return fz(pc) end)
            if ok and grew() then
                rep("原生生成成功 SERVER_SpawnZ()")
                return true, "已生成"
            end
            rep(string.format("试 SERVER_SpawnZ() %s: %s", ok and "调用成功但未生成" or "失败", tostring(err)))
        end
    else
        rep("未找到游戏内控制器 (getGamePC/getPC 均为空)")
    end

    -- ===== 引擎兜底：BeginDeferredActorSpawnFromClass（SDK转储确认5参数） =====
    local gs = game.gamestat()
    if util.valid(gs) and gs.BeginDeferredActorSpawnFromClass ~= nil then
        local ok, res = pcall(function()
            return gs.BeginDeferredActorSpawnFromClass(gs, pawn, cls, tr, 1, nil)
        end)
        if ok and util.valid(res) then
            local ok2, err2 = pcall(function() return gs.FinishSpawningActor(gs, res, tr) end)
            if ok2 and grew() then
                rep("僵尸生成成功: BeginDeferredActorSpawnFromClass")
                return true, "已生成"
            end
            rep(string.format("BeginDeferred 调用完成但未生成 (finish=%s err=%s)", tostring(ok2), tostring(err2)))
        else
            rep(string.format("试 BeginDeferredActorSpawnFromClass 失败: %s", tostring(res)))
        end
    end
    return false, "生成失败(所有方式均无效, 详见日志)"
end

--- 批量生成（界面调用）
function zombies.spawn()
    local entry = zombies.current()
    if not entry then return false end
    local n = zombies.count()
    local okCount = 0
    for _ = 1, n do
        local ok = zombies.autoSpawnOne(entry, true)
        if ok then okCount = okCount + 1 end
    end
    if okCount > 0 then
        zombies.notify(string.format("已生成: %s ×%d", entry.cn, okCount), false)
        return true
    end
    zombies.notify("生成失败: " .. entry.cn, true)
    return false
end

return zombies
