-- ============================================================
--  HTZ TRAINER - HumanitZ 单机内置修改器
--  v1.1.1  |  UE4SS Lua Mod
--  架构：所有游戏对象操作均在游戏主线程执行（修复加载崩溃）
--  按键：进入/确认=小键盘+ 或 =；返回/退出=小键盘- 或 -
--  快捷：小键盘1-9 与 F1-F9（完全等效）
-- ============================================================
local util = require("util")
local config = require("config")
local game = require("game")
local stats = require("stats")
local items = require("items")
local zombies = require("zombies")
local vehicles = require("vehicles")
local world = require("world")
local overlay = require("overlay")

-- ---- 模块互连 ----
stats.notify = overlay.toast
items.notify = overlay.toast
zombies.notify = overlay.toast
vehicles.notify = overlay.toast
world.notify = overlay.toast
overlay.modules = {
    stats = stats, items = items, zombies = zombies, vehicles = vehicles,
    world = world, game = game, config = config,
}

util.log("==============================================")
util.log("HTZ TRAINER v" .. overlay.VERSION .. " 加载中（主线程安全版）...")
util.log("进入/确认: 小键盘+ 或 大键盘=   返回/退出: 小键盘- 或 大键盘-")
util.log("快捷: 小键盘1-9 或 F1-F9(等效) — 1菜单 2上帝 3补满 4全锁 5物品 6僵尸 7世界 8面板 9转储")
util.log("==============================================")

-- ---- 按键注册（全部包装到游戏主线程执行） ----
local function bind(key, name, fn)
    if key == nil then
        util.log("按键注册失败(键名不存在): " .. tostring(name))
        return
    end
    local ok, err = pcall(RegisterKeyBind, key, function()
        util.safe(function() util.debug("按键触发: " .. tostring(name)) end)
        util.inGame(function()
            local ok2, err2 = pcall(fn)
            if not ok2 then util.log("按键任务异常 " .. tostring(name) .. ": " .. tostring(err2)) end
        end)
    end)
    if not ok then util.log("按键注册失败 " .. tostring(name) .. ": " .. tostring(err)) end
end

-- 同一功能注册多个键（小键盘 + F 键）
local function bindMulti(keys, name, fn)
    local bound = false
    for _, k in ipairs(keys) do
        local keyVal = Key[k]
        if keyVal ~= nil then
            bind(keyVal, name .. "(" .. k .. ")", fn)
            bound = true
        end
    end
    if not bound then util.log("功能键全部注册失败: " .. name) end
end

local toggleMenu = function() overlay.toggle() end
local toggleGod = function() stats.setGodMode(not stats.godMode) end
local healAll = function() stats.healAll() end
local toggleLocks = function() stats.toggleAllLocks(not stats.anyLockOnly()) end
local openItems = function() overlay.openPage("items") end
local openZombies = function() overlay.openPage("zombies") end
local openVehicles = function() overlay.openPage("vehicles") end
local openWorld = function() overlay.openPage("world") end
local togglePanel = function()
    overlay.visible = not overlay.visible
    config.set("overlay_on", overlay.visible and "1" or "0")
    config.save()
end
local devDump = function()
    util.log("手动类转储开始（可能短暂卡顿）...")
    util.safe(function()
        game.dumpClass(game.getAttrComp(),
            "attribute|get|set|update|drain|heal|bleed|god|vital|stat|value|infec|hunger|thirst|stamina|health", 400)
    end)
    util.safe(function()
        game.dumpClass(game.getPawn(), "Server_|Spawn|Give|Item|God|Vital|Add|Admin", 200)
    end)
end

-- 快捷功能键：小键盘 1-9 与 大键盘 F1-F9 双份等效（F1=小键盘1 … F9=小键盘9）
bindMulti({ "NUM_ONE", "F1" }, "菜单", toggleMenu)
bindMulti({ "NUM_TWO", "F2" }, "上帝模式", toggleGod)
bindMulti({ "NUM_THREE", "F3" }, "一键补满", healAll)
bindMulti({ "NUM_FOUR", "F4" }, "状态全锁", toggleLocks)
bindMulti({ "NUM_FIVE", "F5" }, "物品生成", openItems)
bindMulti({ "NUM_SIX", "F6" }, "僵尸生成", openZombies)
bindMulti({ "NUM_SEVEN", "F7" }, "世界控制", openWorld)
bindMulti({ "NUM_EIGHT", "F8" }, "状态面板", togglePanel)
bindMulti({ "NUM_NINE", "F9" }, "调试转储", devDump)

bind(Key.UP_ARROW,    "UP",    function() overlay.key("up") end)
bind(Key.DOWN_ARROW,  "DOWN",  function() overlay.key("down") end)
bind(Key.LEFT_ARROW,  "LEFT",  function() overlay.key("left") end)
bind(Key.RIGHT_ARROW, "RIGHT", function() overlay.key("right") end)
bind(Key.PAGE_UP,     "PGUP",  function() overlay.key("pgup") end)
bind(Key.PAGE_DOWN,   "PGDN",  function() overlay.key("pgdn") end)
-- 进入/确认 = 小键盘+ 或 大键盘=     返回/退出 = 小键盘- 或 大键盘-
-- （已按要求移除 小键盘0 和 小键盘. 的进出功能；- 和 = 均不与游戏按键冲突）
bindMulti({ "ADD", "OEM_PLUS" }, "进入/确认(+,=)", function()
    if not overlay.open then
        overlay.openPage("main") -- 菜单关闭时：按 = 直接打开作弊栏主页
    else
        overlay.key("enter")
    end
end)
bindMulti({ "SUBTRACT", "OEM_MINUS" }, "返回/退出(-)", function()
    if overlay.open then overlay.key("esc") end
end)

-- ---- 菜单搜索输入（字母/数字；仅在菜单打开时生效，正常游玩零干扰）----
local function bindSearch(keyName, ch)
    local keyVal = Key[keyName]
    if keyVal == nil then return false end
    local ok = pcall(RegisterKeyBind, keyVal, function()
        -- 菜单未打开时直接返回：不影响游戏、不写日志
        if not overlay.open or overlay.page ~= "itemlist" then return end
        util.inGame(function()
            util.safe(function() overlay.onSearchKey(ch) end)
        end)
    end)
    return ok
end

local searchBound = 0
for c in string.gmatch("ABCDEFGHIJKLMNOPQRSTUVWXYZ", ".") do
    if bindSearch(c, c:lower()) then searchBound = searchBound + 1 end
end
local SEARCH_DIGITS = { ZERO = "0", ONE = "1", TWO = "2", THREE = "3", FOUR = "4",
    FIVE = "5", SIX = "6", SEVEN = "7", EIGHT = "8", NINE = "9" }
for name, ch in pairs(SEARCH_DIGITS) do
    if bindSearch(name, ch) then searchBound = searchBound + 1 end
end
-- 注意：不使用退格(BackSpace)——它是游戏自带的 HUD 显示/隐藏开关键，会误关快捷栏
-- 搜索删除改用 DEL 键（清空搜索：在物品列表按 - 返回键可先清空搜索词）
if bindSearch("DEL", "\b") then searchBound = searchBound + 1 end
util.log("搜索按键注册: " .. searchBound .. "/37 (DEL=删除字符；字母/数字=输入)")

-- ---- 初始绘制钩子（引擎 HUD 基类） ----
local frameHookOK, frameHookErr = pcall(function()
    RegisterHook("/Script/Engine.HUD:ReceiveDrawHUD", function(self, SizeX, SizeY)
        overlay.onFrame(self, SizeX, SizeY)
    end)
end)
util.log("HUD 绘制钩子(基类): " .. tostring(frameHookOK) .. (frameHookOK and "" or (" / " .. tostring(frameHookErr))))

-- ---- 动态绘制钩子：挂钩游戏真实 HUD 类（蓝图重载的事件必须挂到蓝图类上） ----
local hudHookDone = false
local function tryHudHook()
    if hudHookDone or overlay._frameHookSeen then return end
    local hud = FindFirstOf("HUD")
    if not util.valid(hud) then return end
    local clsPath = nil
    util.safe(function()
        local full = hud:GetClass():GetFullName() -- 形如 "BlueprintGeneratedClass /Game/.../BP_X.BP_X_C"
        clsPath = full:match("(/[^ ]+)$")
    end)
    if not clsPath then return end
    local ok, err = pcall(function()
        RegisterHook(clsPath .. ":ReceiveDrawHUD", function(self, SizeX, SizeY)
            overlay.onFrame(self, SizeX, SizeY)
        end)
    end)
    util.log(string.format("动态HUD钩子 %s: %s %s", clsPath, tostring(ok), ok and "" or tostring(err)))
    if ok then hudHookDone = true end
end

-- ---- 主线程任务调度 ----
local tickCount = 0
local settle = tonumber(config.get("settle_seconds")) or 6
local readyClock = nil
local jobQueue = {}
local calibRetries = 0

local function onReady()
    overlay.ready = true
    readyClock = os.clock()
    local pawn = game.getPawn()
    util.log("玩家就绪: " .. (util.valid(pawn) and pawn:GetFullName() or "?"))
    overlay.toast("HTZ 修改器 v" .. overlay.VERSION .. " 就绪 — " .. l10n_ready_hint(), false)
    jobQueue = {
        function()
            local g = io.open("Mods\\HTZ_Trainer\\no_calib.txt", "r")
            if g then g:close(); util.log("属性校准: 已被 no_calib.txt 禁用, 跳过"); return end
            stats.calibrate()
        end,
        function() items.beginScan() end,
        function() world.calibrate() end,
        function() vehicles.preload() end,
        function()
            stats.refreshValues()
            util.log(string.format("属性快照: 生命=%s 耐力=%s 饥饿=%s 口渴=%s 感染=%s 体温=%s 电量=%s | 校准=%s",
                tostring(stats.values.health), tostring(stats.values.stamina),
                tostring(stats.values.hunger), tostring(stats.values.thirst),
                tostring(stats.values.infection), tostring(stats.values.temperature),
                tostring(stats.values.battery), stats.calibNote))
        end,
    }
end

function l10n_ready_hint()
    return "小键盘1 开关菜单"
end

local function tick()
    tickCount = tickCount + 1
    if not overlay.ready then
        if tickCount % 8 == 0 and game.isReady() then
            onReady()
        end
        return
    end
    if not readyClock or (os.clock() - readyClock) < settle then return end

    -- 动态 HUD 钩子（每 ~8 秒尝试一次）
    if (not hudHookDone) and tickCount % 50 == 0 then
        util.safe(tryHudHook)
    end

    if #jobQueue > 0 then
        local job = table.remove(jobQueue, 1)
        util.safe(job)
    elseif (not stats.calibrated) and calibRetries < 5 and tickCount % 75 == 0 then
        calibRetries = calibRetries + 1
        util.safe(stats.calibrate)
    end

    util.safe(function() items.scanStep(tonumber(config.get("item_chunk")) or 35) end)
    if stats.anyLockOn() then
        util.safe(stats.applyLocks)
    end
    if tickCount % 2 == 0 then
        util.safe(stats.refreshValues)
    end
    -- 画布不可用时的文本回退显示
    if not overlay._frameHookSeen then
        util.safe(overlay.renderTextFallback)
    end
end

-- ---- 主线程任务循环（每 150ms；全部在游戏主线程执行，不依赖任何钩子） ----
local pending = false
local pendingSince = 0
LoopAsync(150, function()
    local now = os.clock()
    if pending and (now - pendingSince) < 3 then return false end
    pending = true
    pendingSince = now
    util.inGame(function()
        pending = false
        tick()
    end)
    return false
end)

-- ---- 绘制钩子看门狗（仅提示一次） ----
local hookWarned = false
LoopAsync(5000, function()
    if not overlay._frameHookSeen and not hookWarned then
        hookWarned = true
        util.log("绘制钩子未触发 → 启用屏幕文字模式")
    end
    return false
end)

-- ---- 本地指令通道（调试/校准用） ----
local remote = require("remote")
remote.mods = {
    stats = stats, items = items, zombies = zombies, vehicles = vehicles,
    world = world, game = game, overlay = overlay, config = config,
    main = { tryHudHook = tryHudHook },
}
util.safe(remote.start)

util.log("HTZ TRAINER 初始化完成 (等待进入游戏...)")
