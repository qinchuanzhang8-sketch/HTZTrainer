-- HTZ Trainer v1.1 - 简易配置存取
local util = require("util")

local config = {}
config.PATH = "Mods\\HTZ_Trainer\\config.txt"

config.defaults = {
    ui_language   = "cn",      -- cn / en
    overlay_on    = "1",       -- 状态HUD默认开启
    lock_interval_frames = "9",   -- 锁定应用间隔(帧)
    settle_seconds = "6",      -- 进入游戏后等待稳定秒数再开始校准
    item_chunk    = "35",      -- 物品分类扫描每帧行数
    spawn_dist    = "650",     -- 生成距离
    speed_mult    = "1.0",     -- 移动速度倍率
}

config.data = {}

function config.load()
    for k, v in pairs(config.defaults) do config.data[k] = v end
    local f = io.open(config.PATH, "r")
    if f then
        for line in f:lines() do
            local k, v = line:match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
            if k and v and v ~= "" then config.data[k] = v end
        end
        f:close()
    end
    return config.data
end

function config.get(k)
    return config.data[k] or config.defaults[k]
end

function config.set(k, v)
    config.data[k] = tostring(v)
end

function config.save()
    local f = io.open(config.PATH, "w")
    if not f then return false end
    f:write("# HTZ Trainer 配置文件\n")
    for k, v in pairs(config.data) do
        f:write(string.format("%s = %s\n", k, tostring(v)))
    end
    f:close()
    return true
end

config.load()

return config
