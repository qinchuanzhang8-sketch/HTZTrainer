-- HTZ Trainer v1.1 - 悬浮菜单界面（画布绘制）
-- 通过挂钩 AHUD:ReceiveDrawHUD 每帧绘制；onTick 由 main 注入（游戏主线程任务）
local util = require("util")
local config = require("config")

local overlay = {}

overlay.VERSION = "2.3"
overlay.AMOUNTS = { 1, 2, 3, 5, 10, 20, 50, 100, 200 }
overlay._amountIdx = 5 -- 默认 10
overlay._amountItem = nil
overlay.visible = config.get("overlay_on") ~= "0"
overlay.open = false
overlay.page = "main" -- main/items/itemlist/zombies/world
overlay.sel = 1
overlay.toasts = {}
overlay.ready = false
overlay.modules = {}
overlay.onTick = nil
overlay._frameHookSeen = false
overlay._drawnOnce = false
overlay._textFail = 0
overlay._textOK = false
overlay._boxOK = true
overlay._font = nil
overlay._whiteTex = nil
overlay._fallbackWarned = false

local function rgb(r, g, b, a)
    return { R = r, G = g, B = b, A = a or 1.0 }
end

local C = {
    bg      = rgb(0.04, 0.05, 0.07, 0.84),
    bg2     = rgb(0.07, 0.08, 0.10, 0.90),
    border  = rgb(1.00, 0.62, 0.10, 0.75),
    accent  = rgb(1.00, 0.62, 0.10, 1.00),
    title   = rgb(1.00, 0.72, 0.25, 1.00),
    text    = rgb(0.92, 0.93, 0.95, 1.00),
    dim     = rgb(0.62, 0.65, 0.70, 1.00),
    ok      = rgb(0.30, 0.95, 0.50, 1.00),
    err     = rgb(1.00, 0.32, 0.30, 1.00),
    selbg   = rgb(1.00, 0.62, 0.10, 0.16),
    shadow  = rgb(0, 0, 0, 0.55),
}

local PANEL_X = 26
local VITALS_Y = 86
local MENU_Y = 168
local ROW_H = 23

function overlay.toast(msg, isErr)
    table.insert(overlay.toasts, { msg = tostring(msg), t = os.clock(), color = isErr and C.err or C.ok })
    if #overlay.toasts > 5 then table.remove(overlay.toasts, 1) end
    util.log("[通知] " .. tostring(msg))
end

-- ============ 绘制原语 ============

local function getFont(canvas)
    if util.valid(overlay._font) then return overlay._font end
    local candidates = {}
    local eng = FindFirstOf("GameEngine") or FindFirstOf("Engine")
    if util.valid(eng) then
        for _, p in ipairs({ "SmallFont", "MediumFont", "LargeFont" }) do
            local ok, f = pcall(function() return eng[p] end)
            if ok and util.valid(f) then table.insert(candidates, f) end
        end
    end
    if util.valid(canvas) then
        for _, p in ipairs({ "SmallFont", "LargeFont" }) do
            local ok, f = pcall(function() return canvas[p] end)
            if ok and util.valid(f) then table.insert(candidates, f) end
        end
    end
    local ok, f = pcall(StaticFindObject, "/Engine/EngineFonts/Roboto.Roboto")
    if ok and util.valid(f) then table.insert(candidates, f) end
    for _, font in ipairs(candidates) do
        overlay._font = font
        util.log("字体锁定: " .. font:GetFullName())
        return font
    end
    return nil
end

local function getWhiteTex(canvas)
    if util.valid(overlay._whiteTex) then return overlay._whiteTex end
    if util.valid(canvas) then
        local ok, t = pcall(function() return canvas.DefaultTexture end)
        if ok and util.valid(t) then overlay._whiteTex = t; return t end
    end
    local ok, t = pcall(StaticFindObject, "/Engine/EngineResources/WhiteSquareTexture.WhiteSquareTexture")
    if ok and util.valid(t) then overlay._whiteTex = t; return t end
    return nil
end

local function fillRect(canvas, x, y, w, h, color)
    if not overlay._boxOK or not util.valid(canvas) then return end
    local tex = getWhiteTex(canvas)
    if not tex then overlay._boxOK = false; return end
    local ok = pcall(function()
        canvas:K2_DrawTexture(tex, { X = x, Y = y }, { X = w, Y = h }, { X = 0, Y = 0 }, { X = 1, Y = 1 }, color, 2, 0, { X = 0, Y = 0 })
    end)
    if not ok then overlay._boxOK = false end
end

local function strokeRect(canvas, x, y, w, h, color, thickness)
    if not util.valid(canvas) then return end
    pcall(function()
        canvas:K2_DrawBox({ X = x, Y = y }, { X = w, Y = h }, thickness or 2, color)
    end)
end

local function drawText(canvas, x, y, text, color, scale, centered)
    if overlay._textFail >= 3 then return end
    local font = getFont(canvas)
    if not font then overlay._textFail = 3; return end
    scale = scale or 1.0
    local pos = { X = x, Y = y }
    local scl = { X = scale, Y = scale }
    local shadow = { X = 1, Y = 1 }
    local zero = rgb(0, 0, 0, 0)
    local ok = pcall(function()
        canvas:K2_DrawText(font, text, pos, scl, color, 0.0, C.shadow, shadow, centered == true, false, false, zero)
    end)
    if ok then overlay._textOK = true; return end
    ok = pcall(function()
        canvas:K2_DrawText(font, text, pos, scl, color, 0.0, C.shadow, shadow, centered == true, false, false)
    end)
    if ok then overlay._textOK = true; return end
    ok = pcall(function()
        canvas:K2_DrawText(font, text, pos, scl, color, 0.0, C.shadow, shadow, centered == true, false)
    end)
    if ok then overlay._textOK = true; return end
    overlay._textFail = overlay._textFail + 1
end

local function printFallback(msg, color)
    local g = overlay.modules.game
    local ctx = g and g.getPawn() or nil
    if util.valid(ctx) then
        pcall(function()
            g.kismet():PrintString(ctx, "[HTZ] " .. msg, true, false, color or C.ok, 2.2)
        end)
    end
end

-- ============ 布局 ============

local function l10n(cn, en)
    if config.get("ui_language") == "en" then return en end
    return cn
end

local function drawVitals(canvas)
    local stats = overlay.modules.stats
    if not stats then return end
    local w, h = 560, 86
    local x, y = PANEL_X, VITALS_Y
    fillRect(canvas, x, y, w, h, C.bg)
    strokeRect(canvas, x, y, w, h, C.border, 1)
    local title = l10n("状态面板", "STATUS")
    if overlay.ready and stats.calibNote and stats.calibNote ~= "未校准" then
        title = title .. "   [" .. stats.calibNote .. "]"
    end
    drawText(canvas, x + 12, y + 6, title, C.title, 0.95)

    local line1, line2 = {}, {}
    local order = { "health", "stamina", "hunger", "thirst", "infection", "temperature", "battery" }
    for i, key in ipairs(order) do
        local d
        for _, dd in ipairs(stats.DISPLAY) do if dd.key == key then d = dd end end
        local v = stats.values[key]
        local vs = v and string.format("%.1f", util.round(v, 1)) or "--"
        local lockMark = (key == "health" and stats.godMode) and "[锁]"
            or (stats.locks[key] and "[锁]") or ""
        local seg = string.format("%s %s%s", d and l10n(d.cn, d.en) or key, vs, lockMark)
        if i <= 4 then table.insert(line1, seg) else table.insert(line2, seg) end
    end
    drawText(canvas, x + 12, y + 28, table.concat(line1, "   "), C.text, 1.0)
    drawText(canvas, x + 12, y + 48, table.concat(line2, "   "), C.text, 1.0)
    if not overlay.ready then
        drawText(canvas, x + 12, y + 66, l10n("等待进入游戏...", "Waiting for game..."), C.dim, 0.9)
    end
end

local function devDump()
    local game = overlay.modules.game
    util.log("手动类转储开始...")
    util.safe(function()
        game.dumpClass(game.getAttrComp(),
            "attribute|get|set|update|drain|heal|bleed|god|vital|stat|value|infec|hunger|thirst|stamina|health", 400)
    end)
    util.safe(function()
        game.dumpClass(game.getPawn(), "Server_|Spawn|Give|Item|God|Vital|Add|Admin", 200)
    end)
end

local function rowsMain()
    local S = overlay.modules.stats
    local I = overlay.modules.items
    local Z = overlay.modules.zombies
    local W = overlay.modules.world
    return {
        {
            label = l10n("上帝模式（全属性保护/锁定）", "God Mode (full lock)"), hot = "小键盘2/F2",
            state = function() return S.godMode and l10n("开启", "ON") or l10n("关闭", "OFF") end,
            color = function() return S.godMode and C.ok or C.dim end,
            act = function() S.setGodMode(not S.godMode) end,
        },
        {
            label = l10n("状态全锁（饥饿/口渴/耐力/感染/体温/电量）", "Lock all vitals"), hot = "小键盘4/F4",
            state = function() return S.anyLockOn() and l10n("开启", "ON") or l10n("关闭", "OFF") end,
            color = function() return S.anyLockOn() and C.ok or C.dim end,
            act = function() S.toggleAllLocks(not S.anyLockOn()) end,
        },
        {
            label = l10n("一键补满 + 清除流血/感染", "Heal all + clear debuffs"), hot = "小键盘3/F3",
            state = function() return "" end,
            act = function() S.healAll() end,
        },
        {
            label = l10n("物品生成器（分类）", "Item spawner (categories)"), hot = "小键盘5/F5",
            state = function() return string.format("%d", #I.list) end,
            sub = "items",
        },
        {
            label = l10n("僵尸/怪物生成器", "Zombie spawner"), hot = "小键盘6/F6",
            state = function() return string.format("%d", #Z.data) end,
            sub = "zombies",
        },
        {
            label = l10n("车辆生成器（全部车辆）", "Vehicle spawner"),
            state = function()
                local V = overlay.modules.vehicles
                return V and string.format("%d", #V.data) or ""
            end,
            sub = "vehicles",
        },
        {
            label = l10n("世界控制（时间/天气/速度）", "World (time/weather/speed)"), hot = "小键盘7/F7",
            state = function()
                local t = W.getTime()
                return t and string.format("%02d:00", math.floor(t)) or "--"
            end,
            sub = "world",
        },
        {
            label = l10n("隐藏状态面板", "Hide status panel"), hot = "小键盘8/F8",
            state = function() return overlay.visible and l10n("显示", "SHOWN") or l10n("隐藏", "OFF") end,
            act = function()
                overlay.visible = not overlay.visible
                config.set("overlay_on", overlay.visible and "1" or "0")
                config.save()
            end,
        },
        {
            label = l10n("调试: 转储类函数到日志", "Debug: dump class funcs"), hot = "小键盘9/F9",
            state = function() return "" end,
            act = devDump,
        },
    }
end

local function rowsWorld()
    local W = overlay.modules.world
    return {
        { label = l10n("时间 +1 小时", "Time +1h"), act = function() W.addTime(1) end },
        { label = l10n("时间 -1 小时", "Time -1h"), act = function() W.addTime(-1) end },
        { label = l10n("设为正午 12:00", "Set noon"), act = function() W.setTime(12) end },
        { label = l10n("设为午夜 00:00", "Set midnight"), act = function() W.setTime(0) end },
        { label = l10n("切换天气（随机）", "Random weather"), act = function() W.cycleWeather() end },
        {
            label = l10n("移动速度", "Move speed"),
            state = function() return string.format("%.1fx", W.speedMult) end,
            act = function(dir)
                if dir then W.cycleSpeed(dir == "left" and -1 or 1) end
            end,
        },
        { label = l10n("< 返回", "< Back"), act = function() overlay.page = "main"; overlay.sel = 1 end },
    }
end

function overlay.rowsFor(page)
    if page == "world" then return rowsWorld() end
    return rowsMain()
end

-- ============ 菜单绘制 ============

local function drawRowList(canvas, x, y, w, rows, renderRow)
    for i, row in ipairs(rows) do
        local ry = y + (i - 1) * ROW_H
        if i == overlay.sel then
            fillRect(canvas, x + 4, ry, w - 8, ROW_H, C.selbg)
            fillRect(canvas, x + 4, ry, 3, ROW_H, C.accent)
        end
        renderRow(i, row, ry, i == overlay.sel)
    end
end

local function drawMenu(canvas, W, H)
    local page = overlay.page
    local items = overlay.modules.items
    local zombies = overlay.modules.zombies
    local stats = overlay.modules.stats
    local x, y = PANEL_X, MENU_Y
    local w

    if page == "main" then
        local rows = overlay.rowsFor("main")
        w = 580
        local h = 36 + #rows * ROW_H + 86
        fillRect(canvas, x, y, w, h, C.bg2)
        strokeRect(canvas, x, y, w, h, C.border, 2)
        drawText(canvas, x + 14, y + 9, string.format("HTZ TRAINER v%s", overlay.VERSION), C.title, 1.1)
        drawText(canvas, x + w - 160, y + 11, l10n("单机模式修改器", "SP Trainer"), C.dim, 0.9)
        drawRowList(canvas, x, y + 36, w, rows, function(i, row, ry, selected)
            local label = row.hot and string.format("[%s] %s", row.hot, row.label) or row.label
            drawText(canvas, x + 14, ry + 4, label, selected and C.text or rgb(0.82, 0.84, 0.88, 1), 1.0)
            if row.state then
                local st = row.state()
                local col = row.color and row.color() or C.dim
                drawText(canvas, x + w - 140, ry + 4, st, col, 1.0)
            end
        end)
        local fy = y + 36 + #rows * ROW_H + 10
        drawText(canvas, x + 14, fy, l10n("【按键说明】进入/确认: 小键盘[+] 或 [=]    返回/退出: 小键盘[-] 或 [-]",
            "[KEYS] Enter: Kp[+] or [=]    Back: Kp[-] or [-]"), C.accent, 0.9)
        drawText(canvas, x + 14, fy + 17, l10n("快捷功能: 小键盘1~9 或 F1~F9（等效）— 1菜单 2上帝 3补满 4全锁 5物品 6僵尸 7世界 8面板 9转储",
            "Hotkeys: Kp1-9 = F1-F9 — 1menu 2god 3heal 4locks 5items 6zeds 7world 8HUD 9dump"), C.dim, 0.85)
        drawText(canvas, x + 14, fy + 33, l10n("菜单导航: ↑↓选择 ←→调整 PgUp/PgDn翻页 | 物品搜索: 列表内直接输入字母/数字",
            "Nav: arrows PgUp/Dn | Search: type in item list"), C.dim, 0.85)

    elseif page == "items" then
        -- 分类选择页
        w = 580
        local rows = items.CATS
        local h = 40 + #rows * ROW_H + 46
        fillRect(canvas, x, y, w, h, C.bg2)
        strokeRect(canvas, x, y, w, h, C.border, 2)
        drawText(canvas, x + 14, y + 9, l10n("物品生成器 — 选择分类", "Item Spawner - Category"), C.title, 1.05)
        drawText(canvas, x + w - 180, y + 10, string.format(l10n("共 %d 种", "%d items"), #items.list), C.accent, 1.0)
        drawRowList(canvas, x, y + 40, w, rows, function(i, row, ry, selected)
            local cnt = items.countOf(i)
            drawText(canvas, x + 14, ry + 4, row.label or row.cn,
                selected and C.text or rgb(0.82, 0.84, 0.88, 1), 1.0)
            drawText(canvas, x + w - 100, ry + 4, string.format("(%d)", cnt), C.dim, 1.0)
        end)
        local fy = y + 40 + #rows * ROW_H + 8
        local st = items.scanState
        if st.active then
            drawText(canvas, x + 14, fy, string.format(l10n("正在扫描游戏数据 %d/%d ...", "Scanning %d/%d ..."), st.done, st.total), C.accent, 0.9)
        else
            drawText(canvas, x + 14, fy, l10n("↑↓选择分类    进入/确认: [+]或[=]    返回/退出: [-]或[-]", "Up/Dn   Enter: [+]or[=]   Back: [-]or[-]"), C.dim, 0.9)
        end

    elseif page == "itemlist" then
        -- 物品列表页
        local cat = items.CATS[items.catSel]
        local rows = items.viewRows()
        w = 640
        local h = 50 + math.max(#rows, 1) * 22 + 46
        fillRect(canvas, x, y, w, h, C.bg2)
        strokeRect(canvas, x, y, w, h, C.border, 2)
        local total = items.countFiltered()
        local hdr
        if items.search ~= "" then
            hdr = string.format(l10n("搜索: %s_  %d/%d", "Find: %s_  %d/%d"), items.search, items.sel, total)
        else
            hdr = string.format("%s  %d/%d", cat and (cat.cn or cat.label) or "?", items.sel, total)
        end
        drawText(canvas, x + 14, y + 9, hdr, C.title, 1.05)
        drawText(canvas, x + w - 130, y + 10, string.format(l10n("共%d项", "%d found"), total), C.accent, 1.0)
        for i, r in ipairs(rows) do
            local ry = y + 50 + (i - 1) * 22
            local selected = (r.pos == items.sel)
            if selected then
                fillRect(canvas, x + 4, ry, w - 8, 22, C.selbg)
                fillRect(canvas, x + 4, ry, 3, 22, C.accent)
            end
            local disp = r.disp or r.name
            drawText(canvas, x + 16, ry + 4, (selected and "> " or "  ") .. disp,
                selected and C.text or rgb(0.80, 0.82, 0.86, 1), 0.9)
            drawText(canvas, x + w - 70, ry + 4, string.format("%d", r.pos), C.dim, 0.85)
        end
        local fy = y + 50 + math.max(#rows, 1) * 22 + 8
        drawText(canvas, x + 14, fy, l10n("↑↓滚动 PgUp/PgDn翻页 [字母数字]搜索 [DEL]删除 | 选数量: [+]或[=]  返回: [-]或[-]",
            "Up/Dn Pg type=search DEL=del | Amount: [+]or[=]  Back: [-]or[-]"), C.dim, 0.9)

    elseif page == "amount" then
        local name = tostring(overlay._amountItem or "?")
        w = 460
        local h = 175
        fillRect(canvas, x, y, w, h, C.bg2)
        strokeRect(canvas, x, y, w, h, C.border, 2)
        drawText(canvas, x + 14, y + 10, l10n("刷取数量", "SPAWN AMOUNT"), C.title, 1.1)
        drawText(canvas, x + 14, y + 42, items.display(name), C.text, 1.0)
        local amt = overlay.AMOUNTS[overlay._amountIdx or 1] or 1
        drawText(canvas, x + w / 2, y + 80, string.format("<  %d  >", amt), C.accent, 1.7, true)
        drawText(canvas, x + 14, y + 132, l10n("←→ 或 ↑↓ 调整数量    确认刷取: [+]或[=]    取消: [-]或[-]",
            "L/R U/D amount   Spawn: [+]or[=]   Cancel: [-]or[-]"), C.dim, 0.9)

    elseif page == "vehicles" then
        local V = overlay.modules.vehicles
        local rows = V and V.viewRows() or {}
        w = 640
        local h = 50 + math.max(#rows, 1) * 22 + 46
        fillRect(canvas, x, y, w, h, C.bg2)
        strokeRect(canvas, x, y, w, h, C.border, 2)
        drawText(canvas, x + 14, y + 9, l10n("车辆生成器", "VEHICLE SPAWNER") ..
            string.format("  %d/%d", V and V.sel or 1, V and #V.data or 0), C.title, 1.05)
        drawText(canvas, x + w - 170, y + 10, string.format(l10n("距离 %d", "Dist %d"), V and V.dist or 500), C.accent, 1.0)
        for i, r in ipairs(rows) do
            local ry = y + 50 + (i - 1) * 22
            local selected = (V and r.idx == V.sel)
            if selected then
                fillRect(canvas, x + 4, ry, w - 8, 22, C.selbg)
                fillRect(canvas, x + 4, ry, 3, 22, C.accent)
            end
            local name = string.format("%s  (%s)", r.entry.cn, r.entry.en)
            drawText(canvas, x + 16, ry + 4, (selected and "> " or "  ") .. name,
                selected and C.text or rgb(0.80, 0.82, 0.86, 1), 0.95)
        end
        local fy = y + 50 + math.max(#rows, 1) * 22 + 8
        drawText(canvas, x + 14, fy, l10n("↑↓滚动 PgUp/PgDn翻页 ←→生成距离 | 生成: [+]或[=]  返回: [-]或[-]",
            "Up/Dn Pg L/R dist | Spawn: [+]or[=]  Back: [-]or[-]"), C.dim, 0.9)

    elseif page == "world" then
        local rows = overlay.rowsFor("world")
        w = 580
        local h = 36 + #rows * ROW_H + 60
        fillRect(canvas, x, y, w, h, C.bg2)
        strokeRect(canvas, x, y, w, h, C.border, 2)
        drawText(canvas, x + 14, y + 9, l10n("世界控制（时间/天气/速度）", "WORLD"), C.title, 1.05)
        drawRowList(canvas, x, y + 36, w, rows, function(i, row, ry, selected)
            drawText(canvas, x + 14, ry + 4, row.label, selected and C.text or rgb(0.82, 0.84, 0.88, 1), 1.0)
            if row.state then
                local st = row.state()
                local col = row.color and row.color() or C.dim
                drawText(canvas, x + w - 140, ry + 4, st, col, 1.0)
            end
        end)
        local fy = y + 36 + #rows * ROW_H + 10
        drawText(canvas, x + 14, fy, l10n("↑↓选择 ←→调整 | 执行/确认: [+]或[=]  返回: [-]或[-]",
            "Up/Dn L/R | OK: [+]or[=]  Back: [-]or[-]"), C.dim, 0.9)

    elseif page == "zombies" then
        local rows = zombies.viewRows()
        w = 640
        local h = 50 + math.max(#rows, 1) * 22 + 46
        fillRect(canvas, x, y, w, h, C.bg2)
        strokeRect(canvas, x, y, w, h, C.border, 2)
        drawText(canvas, x + 14, y + 9, l10n("僵尸生成器", "ZOMBIE SPAWNER") .. string.format("  %d/%d", zombies.sel, #zombies.data), C.title, 1.05)
        drawText(canvas, x + w - 130, y + 10, string.format(l10n("数量 %d", "Amount %d"), zombies.count()), C.accent, 1.0)
        for i, r in ipairs(rows) do
            local ry = y + 50 + (i - 1) * 22
            local selected = (r.idx == zombies.sel)
            if selected then
                fillRect(canvas, x + 4, ry, w - 8, 22, C.selbg)
                fillRect(canvas, x + 4, ry, 3, 22, C.accent)
            end
            local name = string.format("%s  (%s)", r.entry.cn, r.entry.en)
            drawText(canvas, x + 16, ry + 4, (selected and "> " or "  ") .. name,
                selected and C.text or rgb(0.80, 0.82, 0.86, 1), 0.95)
        end
        local fy = y + 50 + math.max(#rows, 1) * 22 + 8
        drawText(canvas, x + 14, fy, l10n("↑↓滚动 PgUp/PgDn翻页 ←→数量 | 生成: [+]或[=]  返回: [-]或[-]",
            "Up/Dn PgUp/Dn L/R amount | Spawn: [+]or[=]  Back: [-]or[-]"), C.dim, 0.9)
    end
end

local function drawToasts(canvas, W)
    local now = os.clock()
    local i = 0
    for _, t in ipairs(overlay.toasts) do
        local age = now - t.t
        if age < 3.2 then
            local alpha = util.clamp(3.2 - age, 0, 1)
            local col = { R = t.color.R, G = t.color.G, B = t.color.B, A = alpha }
            drawText(canvas, W / 2, 58 + i * 22, "- " .. t.msg .. " -", col, 1.0, true)
            i = i + 1
        end
    end
    for k = #overlay.toasts, 1, -1 do
        if now - overlay.toasts[k].t >= 3.2 then table.remove(overlay.toasts, k) end
    end
end

local function drawWatermark(canvas, W, H)
    drawText(canvas, W - 230, H - 40, string.format("HTZ TRAINER  v%s", overlay.VERSION), rgb(1, 0.65, 0.15, 0.65), 0.95)
    drawText(canvas, W - 230, H - 24, l10n("单人模式专用 · 联机请勿使用", "SINGLE-PLAYER ONLY"), rgb(1, 1, 1, 0.35), 0.8)
end

function overlay.onFrame(self, sizeX, sizeY)
    overlay._frameHookSeen = true

    if overlay._textFail >= 3 and not overlay._fallbackWarned then
        overlay._fallbackWarned = true
        printFallback(l10n("菜单绘制失败，已切换为提示消息模式", "overlay draw failed, fallback mode"), C.err)
    end
    local hud = nil
    util.safe(function() hud = self:get() end)
    if not util.valid(hud) then return end
    local canvas = nil
    util.safe(function() canvas = hud.Canvas end)
    if not util.valid(canvas) then return end
    overlay._drawnOnce = true

    local W, H = sizeX or 1920, sizeY or 1080
    pcall(function() W = canvas.SizeX or W end)
    pcall(function() H = canvas.SizeY or H end)

    if overlay.visible then
        drawVitals(canvas)
    end
    if overlay.open then
        drawMenu(canvas, W, H)
    end
    drawToasts(canvas, W)
    drawWatermark(canvas, W, H)
end

-- ============ 输入 ============

function overlay.toggle()
    overlay.open = not overlay.open
    if overlay.open then
        overlay.page = "main"
        overlay.sel = 1
    end
end

function overlay.openPage(p)
    if overlay.open and overlay.page == p then
        overlay.open = false
        return
    end
    overlay.open = true
    overlay.page = p
    overlay.sel = 1
end

function overlay.key(kind)
    if not overlay.open then return end
    local page = overlay.page
    local mods = overlay.modules

    if page == "main" or page == "world" then
        local rows = overlay.rowsFor(page)
        if kind == "up" then
            overlay.sel = overlay.sel - 1
            if overlay.sel < 1 then overlay.sel = #rows end
        elseif kind == "down" then
            overlay.sel = overlay.sel + 1
            if overlay.sel > #rows then overlay.sel = 1 end
        elseif kind == "left" or kind == "right" then
            local row = rows[overlay.sel]
            if row and row.act and row.state then
                util.safe(row.act, kind)
            end
        elseif kind == "enter" then
            local row = rows[overlay.sel]
            if row then
                if row.sub then
                    if row.sub == "items" then mods.items.catSel = 1 end
                    overlay.page = row.sub
                    overlay.sel = 1
                elseif row.act then
                    util.safe(row.act, nil)
                end
            end
        elseif kind == "esc" then
            if page == "world" then
                overlay.page = "main"; overlay.sel = 1
            else
                overlay.open = false
            end
        end

    elseif page == "items" then
        -- 分类选择
        local cats = mods.items.CATS
        if kind == "up" then
            overlay.sel = overlay.sel - 1
            if overlay.sel < 1 then overlay.sel = #cats end
        elseif kind == "down" then
            overlay.sel = overlay.sel + 1
            if overlay.sel > #cats then overlay.sel = 1 end
        elseif kind == "enter" then
            mods.items.openCategory(overlay.sel)
            overlay.page = "itemlist"
            overlay.sel = 1
        elseif kind == "pgdn" then
            overlay.sel = util.clamp(overlay.sel + 5, 1, #cats)
        elseif kind == "pgup" then
            overlay.sel = util.clamp(overlay.sel - 5, 1, #cats)
        elseif kind == "esc" then
            overlay.page = "main"; overlay.sel = 1
        end

    elseif page == "itemlist" then
        local it = mods.items
        if kind == "up" then it.move(-1)
        elseif kind == "down" then it.move(1)
        elseif kind == "pgup" then it.jump(-1)
        elseif kind == "pgdn" then it.jump(1)
        elseif kind == "enter" then
            -- 进入数量选择页（先选物品 → 再定数量）
            local name = it.current()
            if name then
                overlay._amountItem = name
                overlay.page = "amount"
            else
                it.notify("当前没有可刷取的物品", true)
            end
        elseif kind == "esc" then
            if it.search ~= "" then
                it.clearSearch() -- 有搜索词时先清空搜索
            else
                overlay.page = "items"; overlay.sel = it.catSel
            end
        end

    elseif page == "amount" then
        local n = #overlay.AMOUNTS
        local idx = overlay._amountIdx or 1
        if kind == "left" or kind == "down" then
            overlay._amountIdx = util.clamp(idx - 1, 1, n)
        elseif kind == "right" or kind == "up" then
            overlay._amountIdx = util.clamp(idx + 1, 1, n)
        elseif kind == "enter" then
            local amt = overlay.AMOUNTS[overlay._amountIdx or 1] or 1
            local name = overlay._amountItem
            overlay.page = "itemlist"
            if name and mods.items then
                util.safe(function() mods.items.give(name, amt) end)
            end
        elseif kind == "esc" then
            overlay.page = "itemlist"
        end

    elseif page == "vehicles" then
        local V = mods.vehicles
        if V then
            if kind == "up" then V.move(-1)
            elseif kind == "down" then V.move(1)
            elseif kind == "pgup" then V.jump(-1)
            elseif kind == "pgdn" then V.jump(1)
            elseif kind == "left" then V.cycleDist(-1)
            elseif kind == "right" then V.cycleDist(1)
            elseif kind == "enter" then util.safe(V.spawn)
            elseif kind == "esc" then
                overlay.page = "main"; overlay.sel = 1
            end
        end

    elseif page == "zombies" then
        local z = mods.zombies
        if kind == "up" then z.move(-1)
        elseif kind == "down" then z.move(1)
        elseif kind == "pgup" then z.jump(-1)
        elseif kind == "pgdn" then z.jump(1)
        elseif kind == "left" then z.cycleCount(-1)
        elseif kind == "right" then z.cycleCount(1)
        elseif kind == "enter" then util.safe(z.spawn)
        elseif kind == "esc" then
            overlay.page = "main"; overlay.sel = 1
        end
    end
end

--- 菜单内文字输入（搜索）：由 main.lua 的字母/数字按键调用
function overlay.onSearchKey(ch)
    if not overlay.open then return end
    if overlay.page ~= "itemlist" then return end
    local it = overlay.modules.items
    if not it then return end
    if ch == "\b" then
        it.backspaceSearch()
    elseif ch == "\127" then
        it.clearSearch()
    else
        it.appendSearch(ch)
    end
end

-- ============ 文本回退模式（画布不可用时，用引擎屏幕消息显示菜单） ============

overlay._textFB = { hash = "", t = 0 }

function overlay.renderTextFallback()
    local g = overlay.modules.game
    if not g then return end
    local ctx = g.getPawn()
    if not util.valid(ctx) then return end
    local kismet = g.kismet()
    if not util.valid(kismet) then return end
    local S = overlay.modules.stats
    local lines = {}
    if overlay.visible and S then
        local seg = {}
        for _, k in ipairs({ "health", "stamina", "hunger", "thirst", "infection", "temperature", "battery" }) do
            local d
            for _, dd in ipairs(S.DISPLAY) do if dd.key == k then d = dd end end
            local v = S.values[k]
            local lock = (k == "health" and S.godMode) or S.locks[k]
            seg[#seg + 1] = string.format("%s:%s%s", (d and d.cn or k),
                v and string.format("%.0f", v) or "--", lock and "·锁" or "")
        end
        lines[#lines + 1] = "【状态】" .. table.concat(seg, "  ")
    end
    if overlay.open and S then
        lines[#lines + 1] = "【HZ修改器】小键盘: 1菜单 2上帝" .. (S.godMode and "+" or "") ..
            " 3补满 4全锁" .. (S.anyLockOn() and "+" or "") .. " 5物品 6僵尸 7世界 8面板 | 快捷: 小键盘1~9 或 F1~F9"
        if overlay.page == "items" then
            local cat = overlay.modules.items.CATS[overlay.sel]
            lines[#lines + 1] = string.format("【物品分类 %d/10】%s (%d种) — 上下选择 进入:[+]或[=] 返回:[-]或[-]",
                overlay.sel, cat and cat.cn or "?", overlay.modules.items.countOf(overlay.sel))
        elseif overlay.page == "itemlist" then
            local it2 = overlay.modules.items
            local shdr = it2.search ~= "" and ("搜索:" .. it2.search .. "_ ") or ""
            lines[#lines + 1] = string.format("【物品】%s%s (%d项) — 上下滚动 [字母]搜索 选数量:[+]或[=] 返回:[-]或[-]",
                shdr, tostring(it2.current()), it2.countFiltered())
        elseif overlay.page == "amount" then
            lines[#lines + 1] = string.format("【刷取数量】%d 个 — ←→调整 确认刷取:[+]或[=] 取消:[-]或[-]",
                overlay.AMOUNTS[overlay._amountIdx or 1] or 1)
        elseif overlay.page == "vehicles" then
            local e = overlay.modules.vehicles and overlay.modules.vehicles.current()
            lines[#lines + 1] = string.format("【车辆】%s — 上下选择 生成:[+]或[=] 返回:[-]或[-]",
                e and e.cn or "?")
        elseif overlay.page == "zombies" then
            local e = overlay.modules.zombies.current()
            lines[#lines + 1] = string.format("【僵尸】%s ×%d — 上下选择 生成:[+]或[=] 返回:[-]或[-]",
                e and e.cn or "?", overlay.modules.zombies.count())
        elseif overlay.page == "world" then
            local t = overlay.modules.world.getTime()
            lines[#lines + 1] = string.format("【世界】时间 %s — 上下列 执行:[+]或[=] 返回:[-]或[-]",
                t and string.format("%02d:00", math.floor(t % 24)) or "--")
        end
    end
    if #overlay.toasts > 0 then
        lines[#lines + 1] = ">> " .. overlay.toasts[#overlay.toasts].msg
    end
    local text = table.concat(lines, "\n")
    local now = os.clock()
    if text ~= overlay._textFB.hash or (now - overlay._textFB.t) > 1.0 then
        overlay._textFB.hash = text
        overlay._textFB.t = now
        for _, l in ipairs(lines) do
            pcall(function()
                kismet:PrintString(ctx, l, true, false, { R = 1, G = 0.72, B = 0.25, A = 1 }, 1.15)
            end)
        end
    end
end

return overlay
