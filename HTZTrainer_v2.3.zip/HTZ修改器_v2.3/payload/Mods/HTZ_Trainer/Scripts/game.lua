-- HTZ Trainer v1.1 - 游戏对象访问层
-- 注意：所有对游戏对象的方法调用只在游戏主线程进行（由调用方保证）
local util = require("util")

local game = {}

local UEHelpers = require("UEHelpers")
game.UEHelpers = UEHelpers

local cache = {
    pc = nil, pawn = nil, attrComp = nil, invComp = nil,
    world = nil, gengine = nil, sky = nil, weather = nil, font = nil,
    dtl = nil, dt = nil, gpc = nil,
}

function game.getPC()
    if util.valid(cache.pc) then return cache.pc end
    local ok, pc = pcall(UEHelpers.GetPlayerController)
    if ok and util.valid(pc) then
        cache.pc = pc
        return pc
    end
    cache.pc = nil
    return nil
end

--- 游戏内(Hmz)玩家控制器实例
--- 注意：主菜单阶段 UEHelpers.GetPlayerController 可能返回菜单控制器
--- （菜单世界 NewMenuTesting 也持有 DefaultPawn），它没有 SERVER_* 管理函数。
--- 此函数强制查找 BP_HmzPlayerController_C 的实际实例（排除CDO），并优先取有玩家的那个。
function game.getGamePC()
    if util.valid(cache.gpc) then return cache.gpc end
    local okList, list = pcall(FindAllOf, "BP_HmzPlayerController_C")
    if okList and list then
        local fallback = nil
        for _, c in pairs(list) do
            if util.valid(c) then
                local full = nil
                util.safe(function() full = c:GetFullName() end)
                if full and not full:find("Default__") then
                    local hasPawn = false
                    util.safe(function() hasPawn = util.valid(c.Pawn) and c.Pawn:IsPlayerControlled() end)
                    if hasPawn then
                        cache.gpc = c
                        return c
                    end
                    fallback = fallback or c
                end
            end
        end
        if fallback then
            cache.gpc = fallback
            return fallback
        end
    end
    return nil
end

function game.getPawn()
    if util.valid(cache.pawn) then return cache.pawn end
    local pc = game.getPC()
    if not pc then return nil end
    local ok, pawn = pcall(function() return pc.Pawn end)
    if ok and util.valid(pawn) and pawn:IsPlayerControlled() then
        cache.pawn = pawn
        return pawn
    end
    cache.pawn = nil
    return nil
end

function game.getWorld()
    if util.valid(cache.world) then return cache.world end
    local pawn = game.getPawn()
    if not pawn then return nil end
    local ok, w = pcall(function() return pawn:GetWorld() end)
    if ok and util.valid(w) then cache.world = w; return w end
    return nil
end

--- 玩家是否在游戏中（角色已就绪）
function game.isReady()
    local pawn = game.getPawn()
    if not util.valid(pawn) then return false end
    local isSurvivor = false
    util.safe(function()
        local clsName = pawn:GetClass():GetFName():ToString()
        isSurvivor = clsName:find("Character") ~= nil
    end)
    return isSurvivor
end

local function findPlayerComponent(shortName)
    local pawn = game.getPawn()
    if not pawn then return nil end
    local comps = FindAllOf(shortName)
    if comps then
        local pawnAddr = pawn:GetAddress()
        for _, c in pairs(comps) do
            if util.valid(c) then
                local ok, owner = pcall(function() return c:GetOwner() end)
                if not (ok and util.valid(owner)) then
                    ok, owner = pcall(function() return c.Owner end)
                end
                if ok and util.valid(owner) and owner:GetAddress() == pawnAddr then
                    return c
                end
            end
        end
    end
    return nil
end

function game.getAttrComp()
    if util.valid(cache.attrComp) then return cache.attrComp end
    cache.attrComp = findPlayerComponent("BP_AttributeComponent_C")
    return cache.attrComp
end

function game.getInvComp()
    if util.valid(cache.invComp) then return cache.invComp end
    cache.invComp = findPlayerComponent("Inventory_Component_C")
    return cache.invComp
end

function game.kismet()
    local ok, lib = pcall(UEHelpers.GetKismetSystemLibrary)
    if ok then return lib end
    return nil
end

function game.mathlib()
    local ok, lib = pcall(UEHelpers.GetKismetMathLibrary)
    if ok then return lib end
    return nil
end

function game.gamestat()
    local ok, lib = pcall(UEHelpers.GetGameplayStatics)
    if ok then return lib end
    return nil
end

function game.gengine()
    if util.valid(cache.gengine) then return cache.gengine end
    local e = FindFirstOf("GameEngine") or FindFirstOf("Engine")
    if util.valid(e) then cache.gengine = e; return e end
    return nil
end

function game.getSky()
    if util.valid(cache.sky) then return cache.sky end
    local s = FindFirstOf("Ultra_Dynamic_Sky_C")
    if util.valid(s) then cache.sky = s; return s end
    return nil
end

function game.getWeather()
    if util.valid(cache.weather) then return cache.weather end
    local w = FindFirstOf("Ultra_Dynamic_Weather_C")
    if util.valid(w) then cache.weather = w; return w end
    return nil
end

--- DataTable 函数库（默认对象）
function game.getDTL()
    if util.valid(cache.dtl) then return cache.dtl end
    local ok, lib = pcall(StaticFindObject, "/Script/Engine.Default__DataTableFunctionLibrary")
    if ok and util.valid(lib) then cache.dtl = lib; return lib end
    return nil
end

--- 物品数据库表
function game.getDT()
    if util.valid(cache.dt) then return cache.dt end
    local ok, dt = pcall(StaticFindObject, "/Game/TSS_Game/Data/Localization/DT_ItemDatabase.DT_ItemDatabase")
    if ok and util.valid(dt) then cache.dt = dt; return dt end
    return nil
end

--- 按路径查找类（必要时触发资产加载）
function game.findClass(path)
    local ok, cls = pcall(StaticFindObject, path)
    if ok and util.valid(cls) then return cls end
    return nil
end

--- 类函数转储（开发者用途；过滤支持 a|b|c 语法）
function game.dumpClass(obj, filter, maxLines)
    if not util.valid(obj) then
        util.log("类转储: 对象无效")
        return
    end
    maxLines = maxLines or 150
    local count = 0
    local cls = nil
    util.safe(function()
        if obj:IsClass() then cls = obj else cls = obj:GetClass() end
    end)
    if not util.valid(cls) then return end
    util.log(string.format("---- 类转储: %s ----", cls:GetFullName()))
    pcall(function()
        cls:ForEachFunction(function(fn)
            if count >= maxLines then return true end
            local name = nil
            util.safe(function() name = fn:GetFName():ToString() end)
            if name and (filter == nil or util.matchAny(name, filter)) then
                local params = {}
                util.safe(function()
                    fn:ForEachProperty(function(p)
                        local pn = nil
                        util.safe(function() pn = p:GetFName():ToString() end)
                        if pn then table.insert(params, pn) end
                    end)
                end)
                util.log(string.format("  fn %s(%s)", name, table.concat(params, ", ")))
                count = count + 1
            end
        end)
    end)
end

return game
